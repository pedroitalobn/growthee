import { ChatInterface } from '@/components/dashboard/chat-interface'

export default function ChatPage() {
  return <ChatInterface />
}