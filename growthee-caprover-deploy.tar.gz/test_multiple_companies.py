#!/usr/bin/env python3
"""
Script para testar o enriquecimento de múltiplas empresas
"""

import requests
import json
import time

def test_company_enrichment(domain, expected_name=None):
    """Testa o enriquecimento de uma empresa específica"""
    url = "http://localhost:8000/api/v1/enrich/company"
    
    payload = {
        "domain": domain
    }
    
    print(f"\n=== Testando: {domain} ===")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    
    try:
        response = requests.post(url, json=payload, timeout=60)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"Response Body: {json.dumps(data, indent=2)}")
            
            # Contar campos preenchidos
            filled_fields = []
            for key, value in data.items():
                if value and value != "" and value != [] and value != {}:
                    filled_fields.append(key)
            
            print(f"\nCampos preenchidos: {filled_fields}")
            print(f"Total de campos preenchidos: {len(filled_fields)}")
            
            if expected_name and data.get('name'):
                if expected_name.lower() in data['name'].lower():
                    print(f"✅ Nome correto encontrado: {data['name']}")
                else:
                    print(f"⚠️  Nome encontrado: {data['name']} (esperado: {expected_name})")
            
            return True
        else:
            print(f"❌ Erro: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Erro na requisição: {e}")
        return False

def main():
    """Testa múltiplas empresas"""
    companies = [
        ("microsoft.com", "Microsoft"),
        ("google.com", "Google"),
        ("apple.com", "Apple"),
        ("amazon.com", "Amazon"),
        ("netflix.com", "Netflix")
    ]
    
    results = []
    
    for domain, expected_name in companies:
        success = test_company_enrichment(domain, expected_name)
        results.append((domain, success))
        
        # Pausa entre requisições para não sobrecarregar
        time.sleep(2)
    
    print("\n=== RESUMO DOS TESTES ===")
    successful = 0
    for domain, success in results:
        status = "✅ SUCESSO" if success else "❌ FALHOU"
        print(f"{domain}: {status}")
        if success:
            successful += 1
    
    print(f"\nTotal: {successful}/{len(results)} testes bem-sucedidos")
    print(f"Taxa de sucesso: {(successful/len(results)*100):.1f}%")

if __name__ == "__main__":
    main()