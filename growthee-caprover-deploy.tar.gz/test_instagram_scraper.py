import asyncio
import os
import sys
import json
from dotenv import load_dotenv

# Add the project root to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services.hyperbrowser_instagram_scraper import HyperbrowserInstagramScraperService
from api.services.puppeteer_instagram_scraper import PuppeteerInstagramScraperService
from api.log_service import LogService

async def test_instagram_scraper():
    # Initialize services
    log_service = LogService()
    hyperbrowser_scraper = HyperbrowserInstagramScraperService(log_service)
    playwright_scraper = PuppeteerInstagramScraperService(log_service)
    
    # Check if API key is set
    firecrawl_api_key = os.getenv("FIRECRAWL_API_KEY")
    if not firecrawl_api_key:
        print("\nWARNING: FIRECRAWL_API_KEY environment variable is not set.")
        print("The test will run but API calls will likely fail with 403 Forbidden errors.")
        print("Set the API key in your .env file to test with real API calls.\n")
    
    # Test URLs
    test_urls = [
        "https://www.instagram.com/nike/",
        "https://www.instagram.com/apple/",
        "https://www.instagram.com/microsoft/"
    ]
    
    for url in test_urls:
        print(f"\nTesting URL: {url}")
        
        # Testar Hyperbrowser scraper
        print("\n--- Testing Hyperbrowser Instagram Scraper ---")
        try:
            hyperbrowser_result = await hyperbrowser_scraper.scrape_profile(url)
            if "error" in hyperbrowser_result:
                print(f"Error: {hyperbrowser_result['error']}")
                print("This is expected if you don't have a valid API key.")
            else:
                print("Success! Data extracted:")
                data = hyperbrowser_result.get("data", {})
                print(f"Username: {data.get('username')}")
                print(f"Name: {data.get('name')}")
                print(f"Bio: {data.get('bio')}")
                print(f"Followers: {data.get('followers')} ({data.get('followers_count')})")
                print(f"Following: {data.get('following')} ({data.get('following_count')})")
                print(f"Posts: {data.get('posts')} ({data.get('posts_count')})")
                print(f"Website: {data.get('website')}")
                print(f"Email: {data.get('email')}")
                print(f"Business Category: {data.get('business_category')}")
        except Exception as e:
            print(f"Hyperbrowser Exception: {str(e)}")
        
        # Testar Playwright scraper
        print("\n--- Testing Playwright Instagram Scraper ---")
        try:
            playwright_result = await playwright_scraper.scrape_profile(url)
            if "error" in playwright_result:
                print(f"Error: {playwright_result['error']}")
            else:
                print("Success! Data extracted:")
                data = playwright_result.get("data", {})
                print(f"Username: {data.get('username')}")
                print(f"Name: {data.get('name')}")
                print(f"Bio: {data.get('bio')}")
                print(f"Followers: {data.get('followers')} ({data.get('followers_count')})")
                print(f"Following: {data.get('following')} ({data.get('following_count')})")
                print(f"Posts: {data.get('posts')} ({data.get('posts_count')})")
                print(f"Website: {data.get('website')}")
                print(f"Email: {data.get('email')}")
                print(f"Business Category: {data.get('business_category')}")
                
                # Print raw data for debugging
                print("\nRaw data:")
                print(json.dumps(data, indent=2))
        except Exception as e:
             print(f"Playwright Exception: {str(e)}")

if __name__ == "__main__":
    load_dotenv()
    asyncio.run(test_instagram_scraper())