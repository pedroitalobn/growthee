import asyncio
import httpx
import json

async def test_real_company():
    """Testa o enriquecimento com uma empresa real"""
    
    # Testar com uma empresa conhecida
    test_data = {
        "domain": "microsoft.com"
    }
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "http://localhost:8000/api/v1/enrich/company",
                json=test_data,
                timeout=60.0
            )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Response Body: {json.dumps(result, indent=2)}")
            
            # Verificar se algum campo foi preenchido
            filled_fields = []
            for key, value in result.items():
                if value and value != "null" and key != "error":
                    if isinstance(value, list) and len(value) > 0:
                        filled_fields.append(key)
                    elif isinstance(value, dict) and len(value) > 0:
                        filled_fields.append(key)
                    elif isinstance(value, str) and value.strip():
                        filled_fields.append(key)
            
            print(f"\nCampos preenchidos: {filled_fields}")
            print(f"Total de campos preenchidos: {len(filled_fields)}")
            
        else:
            print(f"Error: {response.status_code}")
            print(f"Response: {response.text}")
    
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_real_company())