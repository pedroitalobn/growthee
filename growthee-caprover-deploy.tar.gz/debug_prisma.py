import asyncio
from prisma import Prisma

async def test_prisma():
    db = Prisma()
    await db.connect()
    
    try:
        # Testar busca de usuário
        print("Testando busca de usuário...")
        user = await db.user.find_unique(
            where={"email": "test@test.com"},
            select={"id": True, "email": True, "creditsRemaining": True, "creditsTotal": True}
        )
        print(f"Usuário encontrado: {user}")
        
        # Testar atualização de créditos
        print("\nTestando atualização de créditos...")
        updated_user = await db.user.update(
            where={"id": user.id},
            data={
                "creditsRemaining": {"increment": 100},
                "creditsTotal": {"increment": 100}
            }
        )
        print(f"Usuário atualizado: {updated_user}")
        
    except Exception as e:
        print(f"Erro: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await db.disconnect()

if __name__ == "__main__":
    asyncio.run(test_prisma())