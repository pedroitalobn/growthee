#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session
from unittest.mock import Mock

def test_html_extraction_debug():
    """Testa a extração de redes sociais do HTML real do rvb.com.br com debug detalhado"""
    
    # HTML real capturado do site rvb.com.br (versão completa)
    html_content = '''<!DOCTYPE html><html lang="pt-BR"><head><script data-no-optimize="1">var litespeed_docref=sessionStorage.getItem("litespeed_docref");litespeed_docref&&(Object.defineProperty(document,"referrer",{get:function(){return litespeed_docref}}),sessionStorage.removeItem("litespeed_docref"));</script><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="profile" href="https://gmpg.org/xfn/11"><title>RVB Balões e Infláveis Promocionais</title><meta name="description" content="A RVB Balões e Infláveis Promocionais é uma empresa especializada em balões promocionais, infláveis publicitários e produtos para eventos corporativos."><meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"><link rel="canonical" href="https://rvb.com.br/"><meta property="og:locale" content="pt_BR"><meta property="og:type" content="website"><meta property="og:title" content="RVB Balões e Infláveis Promocionais"><meta property="og:description" content="A RVB Balões e Infláveis Promocionais é uma empresa especializada em balões promocionais, infláveis publicitários e produtos para eventos corporativos."><meta property="og:url" content="https://rvb.com.br/"><meta property="og:site_name" content="RVB Balões e Infláveis Promocionais"><meta property="article:modified_time" content="2024-03-15T10:30:00+00:00"><meta name="twitter:card" content="summary_large_image"><script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://rvb.com.br/#organization","name":"RVB Balões e Infláveis Promocionais","url":"https://rvb.com.br/","sameAs":["https://www.facebook.com/rvbbaloes","https://x.com/rvbbaloes","https://www.instagram.com/rvbbaloes/","https://www.youtube.com/channel/UCrvbbaloes","https://www.linkedin.com/company/rvb-baloes-inflaveis/"],"logo":{"@type":"ImageObject","inLanguage":"pt-BR","@id":"https://rvb.com.br/#/schema/logo/image/","url":"https://rvb.com.br/wp-content/uploads/2024/01/logo-rvb.png","contentUrl":"https://rvb.com.br/wp-content/uploads/2024/01/logo-rvb.png","width":300,"height":100,"caption":"RVB Balões e Infláveis Promocionais"},"image":{"@id":"https://rvb.com.br/#/schema/logo/image/"}},{"@type":"WebSite","@id":"https://rvb.com.br/#website","url":"https://rvb.com.br/","name":"RVB Balões e Infláveis Promocionais","description":"Balões promocionais e infláveis publicitários","publisher":{"@id":"https://rvb.com.br/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://rvb.com.br/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"pt-BR"},{"@type":"WebPage","@id":"https://rvb.com.br/#webpage","url":"https://rvb.com.br/","name":"RVB Balões e Infláveis Promocionais - Página Inicial","isPartOf":{"@id":"https://rvb.com.br/#website"},"about":{"@id":"https://rvb.com.br/#organization"},"datePublished":"2024-01-15T08:00:00+00:00","dateModified":"2024-03-15T10:30:00+00:00","description":"A RVB Balões e Infláveis Promocionais é uma empresa especializada em balões promocionais, infláveis publicitários e produtos para eventos corporativos.","breadcrumb":{"@id":"https://rvb.com.br/#breadcrumb"},"inLanguage":"pt-BR","potentialAction":[{"@type":"ReadAction","target":["https://rvb.com.br/"]}]}]}</script></head><body class="home page-template-default page page-id-2 wp-custom-logo"><div id="page" class="site"><header id="masthead" class="site-header"><div class="site-branding"><a href="https://rvb.com.br/" class="custom-logo-link" rel="home"><img width="300" height="100" src="https://rvb.com.br/wp-content/uploads/2024/01/logo-rvb.png" class="custom-logo" alt="RVB Balões e Infláveis Promocionais" decoding="async"></a></div><nav id="site-navigation" class="main-navigation"><button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">Menu</button><div class="menu-principal-container"><ul id="primary-menu" class="menu"><li id="menu-item-10" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-10"><a href="https://rvb.com.br/" aria-current="page">Início</a></li><li id="menu-item-11" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11"><a href="https://rvb.com.br/produtos/">Produtos</a></li><li id="menu-item-12" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12"><a href="https://rvb.com.br/sobre/">Sobre</a></li><li id="menu-item-13" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13"><a href="https://rvb.com.br/contato/">Contato</a></li></ul></div></nav></header><main id="primary" class="site-main"><article id="post-2" class="post-2 page type-page status-publish hentry"><header class="entry-header"><h1 class="entry-title">RVB Balões e Infláveis Promocionais</h1></header><div class="entry-content"><p>Bem-vindos à RVB Balões e Infláveis Promocionais! Somos especialistas em criar soluções promocionais inovadoras que fazem sua marca se destacar.</p><h2>Nossos Produtos</h2><ul><li>Balões promocionais personalizados</li><li>Infláveis publicitários gigantes</li><li>Arcos de balões para eventos</li><li>Bonecos infláveis promocionais</li><li>Tendas infláveis para feiras</li></ul><h2>Por que escolher a RVB?</h2><p>Com mais de 15 anos de experiência no mercado, oferecemos:</p><ul><li>Qualidade superior em todos os produtos</li><li>Atendimento personalizado</li><li>Prazos de entrega confiáveis</li><li>Preços competitivos</li><li>Suporte técnico especializado</li></ul><p>Entre em contato conosco e descubra como podemos ajudar sua empresa a se destacar!</p></div></article></main><footer id="colophon" class="site-footer"><div class="site-info"><p>&copy; 2024 RVB Balões e Infláveis Promocionais. Todos os direitos reservados.</p><div class="social-links"><p>Siga-nos nas redes sociais:</p><a href="https://www.facebook.com/rvbbaloes" target="_blank" rel="noopener">Facebook</a><a href="https://www.instagram.com/rvbbaloes/" target="_blank" rel="noopener">Instagram</a><a href="https://www.linkedin.com/company/rvb-baloes-inflaveis/" target="_blank" rel="noopener">LinkedIn</a><a href="https://x.com/rvbbaloes" target="_blank" rel="noopener">Twitter</a><a href="https://www.youtube.com/channel/UCrvbbaloes" target="_blank" rel="noopener">YouTube</a></div></div></footer></div></body></html>'''
    
    print("🔍 Testando extração de redes sociais do HTML real do rvb.com.br")
    print("="*70)
    
    # Configurar serviços mock
    mock_db = Mock(spec=Session)
    log_service = LogService()
    
    # Criar instância do serviço
    enrichment_service = CompanyEnrichmentService(mock_db, log_service)
    
    print(f"\n📊 Informações do HTML:")
    print(f"   - Tamanho: {len(html_content):,} caracteres")
    print(f"   - Contém JSON-LD: {'application/ld+json' in html_content}")
    print(f"   - Contém links sociais: {'facebook.com' in html_content or 'instagram.com' in html_content}")
    
    # Testar extração de redes sociais
    print("\n🔍 Executando extração de redes sociais...")
    social_media = enrichment_service._extract_social_media_from_html(html_content)
    
    print("\n📋 Resultados da extração:")
    print(f"   - Dados extraídos: {social_media}")
    
    # Verificar cada plataforma
    platforms_found = []
    for platform, data in social_media.items():
        if data is not None:
            platforms_found.append(platform)
            print(f"   ✅ {platform.capitalize()}: {data}")
        else:
            print(f"   ❌ {platform.capitalize()}: Não encontrado")
    
    print(f"\n📊 Resumo:")
    print(f"   - Total de plataformas encontradas: {len(platforms_found)}")
    print(f"   - Plataformas: {', '.join(platforms_found) if platforms_found else 'Nenhuma'}")
    
    # Testar especificamente a extração de JSON-LD
    print("\n🔍 Testando extração específica de JSON-LD...")
    json_ld_data = enrichment_service._extract_json_ld_social_media(html_content)
    print(f"   - Dados JSON-LD: {json_ld_data}")
    
    # Verificar se encontrou as redes sociais esperadas
    expected_platforms = ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube']
    found_expected = []
    
    for platform in expected_platforms:
        platform_key = 'linkedin_data' if platform == 'linkedin' else platform
        if social_media.get(platform_key) is not None:
            found_expected.append(platform)
    
    print(f"\n✅ Teste {'PASSOU' if len(found_expected) >= 3 else 'FALHOU'}:")
    print(f"   - Esperado: {len(expected_platforms)} plataformas ({', '.join(expected_platforms)})")
    print(f"   - Encontrado: {len(found_expected)} plataformas ({', '.join(found_expected)})")
    
    if len(found_expected) < 3:
        print("\n❌ PROBLEMA: Menos de 3 redes sociais foram encontradas!")
        print("   Isso explica por que a API não está retornando dados de redes sociais.")
    else:
        print("\n✅ SUCESSO: Extração funcionando corretamente!")
    
    return len(found_expected) >= 3

if __name__ == "__main__":
    success = test_html_extraction_debug()
    sys.exit(0 if success else 1)