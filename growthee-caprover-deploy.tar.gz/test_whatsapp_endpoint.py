#!/usr/bin/env python3

import requests
import json

def test_whatsapp_scrape():
    """Testa o endpoint de scraping do WhatsApp"""
    url = "http://localhost:8000/api/v1/scrapp/whatsapp/test"
    
    # Dados de teste - URL do WhatsApp Business
    data = {
        "url": "https://wa.me/5511999999999",
        "use_hyperbrowser": True
    }
    
    print("\n=== Testando Scraping do WhatsApp ===")
    print(f"URL: {url}")
    print(f"Dados: {json.dumps(data, indent=2)}")
    
    try:
        response = requests.post(url, json=data, timeout=60)
        print(f"\nStatus: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Resposta: {json.dumps(result, indent=2, ensure_ascii=False)}")
        else:
            print(f"Erro: {response.text}")
            
    except Exception as e:
        print(f"Erro na requisição: {str(e)}")

def test_whatsapp_search():
    """Testa o endpoint de busca do WhatsApp Business"""
    url = "http://localhost:8000/api/v1/scrapp/whatsapp/search/test"
    
    # Dados de teste - busca por empresa
    data = {
        "business_name": "McDonald's",
        "location": "São Paulo, SP",
        "use_hyperbrowser": True
    }
    
    print("\n=== Testando Busca do WhatsApp Business ===")
    print(f"URL: {url}")
    print(f"Dados: {json.dumps(data, indent=2)}")
    
    try:
        response = requests.post(url, json=data, timeout=60)
        print(f"\nStatus: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Resposta: {json.dumps(result, indent=2, ensure_ascii=False)}")
        else:
            print(f"Erro: {response.text}")
            
    except Exception as e:
        print(f"Erro na requisição: {str(e)}")

if __name__ == "__main__":
    print("Iniciando testes dos endpoints do WhatsApp...")
    
    # Testar scraping de URL específica
    test_whatsapp_scrape()
    
    # Testar busca de empresa
    test_whatsapp_search()
    
    print("\nTestes concluídos!")