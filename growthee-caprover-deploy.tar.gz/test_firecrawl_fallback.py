#!/usr/bin/env python3

import os
import sys
import asyncio
import json
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

# Adicionar o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session

async def test_firecrawl_with_fallback():
    """Testa a função _scrape_with_firecrawl com fallback de requests"""
    
    # Configurar serviços
    log_service = LogService()
    enrichment_service = CompanyEnrichmentService(None, log_service)
    
    # URL de teste
    url = "https://rvb.com.br"
    
    # Schema de teste
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "description": {"type": "string"},
            "industry": {"type": "string"},
            "social_media": {
                "type": "object",
                "properties": {
                    "instagram": {"type": "string"},
                    "linkedin": {"type": "string"},
                    "facebook": {"type": "string"},
                    "twitter": {"type": "string"},
                    "youtube": {"type": "string"},
                    "whatsapp": {"type": "string"}
                }
            }
        }
    }
    
    print("=== TESTE: Firecrawl com Fallback de Requests ===")
    print(f"URL: {url}")
    
    # Testar a função _scrape_with_firecrawl
    result = await enrichment_service._scrape_with_firecrawl(url, schema)
    
    print(f"\nResultado completo:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    # Verificar se redes sociais foram encontradas
    social_media = result.get('social_media', {})
    
    print(f"\n=== REDES SOCIAIS EXTRAÍDAS ===")
    for platform, url_value in social_media.items():
        if url_value:
            print(f"✅ {platform}: {url_value}")
        else:
            print(f"❌ {platform}: Não encontrado")
    
    # Verificar se o fallback foi acionado
    has_social_media = any([
        social_media.get('instagram'),
        social_media.get('linkedin'),
        social_media.get('facebook'),
        social_media.get('twitter'),
        social_media.get('youtube'),
        social_media.get('whatsapp')
    ])
    
    if has_social_media:
        print("\n✅ Redes sociais foram encontradas!")
    else:
        print("\n❌ Nenhuma rede social foi encontrada.")
    
    # Verificar se há erro
    if 'error' in result:
        print(f"\n❌ Erro encontrado: {result['error']}")
    
    return result

if __name__ == "__main__":
    result = asyncio.run(test_firecrawl_with_fallback())