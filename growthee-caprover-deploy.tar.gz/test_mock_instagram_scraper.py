import asyncio
import json
from api.log_service import LogService
from api.services.mock_instagram_scraper import MockInstagramScraperService

async def test_mock_instagram_scraper():
    """Test the MockInstagramScraperService"""
    print("\n===== Testing MockInstagramScraperService =====\n")
    
    # Initialize services
    log_service = LogService()
    instagram_scraper = MockInstagramScraperService(log_service)
    
    # Test URLs
    test_urls = [
        "https://www.instagram.com/nike/",
        "https://www.instagram.com/apple/",
        "https://www.instagram.com/microsoft/",
        "https://www.instagram.com/unknown_company_profile/"
    ]
    
    for url in test_urls:
        print(f"\nTesting URL: {url}")
        try:
            # Call the scraper method
            result = await instagram_scraper.scrape_profile(url)
            
            # Print the result
            print(f"Result for {url}:")
            print(json.dumps(result, indent=2))
            
            # Check if we got expected data
            if "error" in result:
                print(f"Error: {result['error']}")
            elif "data" in result:
                data = result["data"]
                print(f"Success! Extracted data for {data.get('username')}")
                print(f"Name: {data.get('name')}")
                print(f"Bio: {data.get('bio')}")
                print(f"Followers: {data.get('followers_count')}")
                print(f"Following: {data.get('following_count')}")
                print(f"Posts: {data.get('posts_count')}")
                print(f"Website: {data.get('website')}")
                print(f"Email: {data.get('email')}")
                print(f"Business Category: {data.get('business_category')}")
                print(f"Location: {data.get('location')}")
        
        except Exception as e:
            print(f"Exception: {str(e)}")

if __name__ == "__main__":
    asyncio.run(test_mock_instagram_scraper())