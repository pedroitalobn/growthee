import bcrypt

# Hash do banco de dados
stored_hash = "$2b$12$SzzpgO.Ey1d8ectg9BqT1u4TFg0yXdPJ8F/MV1G/smRKnYuwgDxvi"

# Senhas para testar
passwords_to_test = ["@Story987", "client", "Client", "CLIENT"]

print("Testing password verification:")
for password in passwords_to_test:
    try:
        # Converter hash para bytes se necessário
        hash_bytes = stored_hash.encode('utf-8') if isinstance(stored_hash, str) else stored_hash
        password_bytes = password.encode('utf-8')
        
        result = bcrypt.checkpw(password_bytes, hash_bytes)
        print(f"Password '{password}': {result}")
    except Exception as e:
        print(f"Error testing '{password}': {e}")

print("\nTesting hash format:")
print(f"Hash: {stored_hash}")
print(f"Hash length: {len(stored_hash)}")
print(f"Hash starts with $2b$: {stored_hash.startswith('$2b$')}")