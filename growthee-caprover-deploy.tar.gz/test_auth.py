#!/usr/bin/env python3
import asyncio
import os
import bcrypt
from dotenv import load_dotenv
from prisma import Prisma
from api.database import set_prisma_instance, get_db

# Load environment variables
load_dotenv()

async def test_auth():
    """Test authentication flow directly"""
    prisma = Prisma()
    
    try:
        await prisma.connect()
        set_prisma_instance(prisma)
        print("Connected to database")
        
        # Test direct query
        user = await prisma.user.find_unique(
            where={"email": "client@client.com"}
        )
        
        if user:
            print(f"Direct query - User found: {user.email}")
            print(f"Password hash: {user.passwordHash[:20]}...")
            
            # Test password verification
            password_hash = user.passwordHash.encode('utf-8') if isinstance(user.passwordHash, str) else user.passwordHash
            password_valid = bcrypt.checkpw("client".encode('utf-8'), password_hash)
            print(f"Password valid: {password_valid}")
        else:
            print("Direct query - User not found!")
            
        # Test via get_db function
        async for db in get_db():
            user2 = await db.user.find_unique(
                where={"email": "client@client.com"}
            )
            if user2:
                print(f"get_db query - User found: {user2.email}")
            else:
                print("get_db query - User not found!")
            break
            
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        await prisma.disconnect()
        print("Disconnected from database")

if __name__ == "__main__":
    asyncio.run(test_auth())