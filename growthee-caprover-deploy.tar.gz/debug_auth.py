#!/usr/bin/env python3
import asyncio
from prisma import Prisma

async def debug_auth():
    prisma = Prisma()
    await prisma.connect()
    
    try:
        print("Testing different query approaches...")
        
        # Test 1: Simple email query
        print("\n1. Testing email query:")
        user = await prisma.user.find_unique(
            where={"email": "admin@admin.com"}
        )
        print(f"Found user by email: {user.email if user else 'None'}")
        
        # Test 2: Try fullName query
        print("\n2. Testing fullName query:")
        try:
            user2 = await prisma.user.find_unique(
                where={"fullName": "Super Admin"}
            )
            print(f"Found user by fullName: {user2.email if user2 else 'None'}")
        except Exception as e:
            print(f"Error with fullName query: {e}")
        
        # Test 3: List all users to see what fields are available
        print("\n3. Listing all users:")
        users = await prisma.user.find_many()
        for u in users:
            print(f"User: {u.email}, fullName: {u.fullName}")
            
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        await prisma.disconnect()

if __name__ == "__main__":
    asyncio.run(debug_auth())