#!/usr/bin/env python3
"""
Teste da integração da busca por redes sociais em páginas de contato
"""

import asyncio
import sys
import os
from dotenv import load_dotenv

# Adicionar o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

load_dotenv()

async def test_contact_social_integration():
    """Testa a integração da busca por redes sociais em páginas de contato"""
    
    # Setup básico
    engine = create_engine("sqlite:///test.db")
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db_session = SessionLocal()
    
    log_service = LogService()
    enrichment_service = CompanyEnrichmentService(db_session, log_service)
    
    # URL de teste - RVB que sabemos que tem redes sociais na página de contato
    test_url = "https://rvb.com.br"
    
    print(f"\n=== Testando busca integrada de redes sociais ===")
    print(f"URL: {test_url}")
    print("\n1. Testando scraping principal com fallback para páginas de contato...")
    
    try:
        # Testar o scraping principal que agora inclui busca em páginas de contato
        result = await enrichment_service._scrape_company_website(test_url)
        
        print(f"\nResultado do scraping:")
        print(f"- Sucesso: {result.get('success')}")
        print(f"- Fonte: {result.get('source')}")
        print(f"- Confidence Score: {result.get('confidence_score')}")
        
        data = result.get('data', {})
        
        # Verificar redes sociais encontradas
        print(f"\n=== Redes Sociais Encontradas ===")
        
        # Verificar no nível raiz
        social_platforms = ['instagram', 'linkedin', 'facebook', 'youtube', 'whatsapp', 'twitter']
        found_social = False
        
        for platform in social_platforms:
            url = data.get(platform)
            if url:
                print(f"- {platform.capitalize()}: {url}")
                found_social = True
        
        # Verificar em social_media
        social_media = data.get('social_media', {})
        if isinstance(social_media, dict):
            print(f"\n=== Social Media Object ===")
            for platform, url in social_media.items():
                if url:
                    print(f"- {platform.capitalize()}: {url}")
                    found_social = True
        
        if not found_social:
            print("❌ Nenhuma rede social encontrada")
        else:
            print("\n✅ Redes sociais encontradas com sucesso!")
        
        # Testar função de verificação
        print(f"\n=== Teste da função _check_social_media_found ===")
        has_social = enrichment_service._check_social_media_found(data)
        print(f"- Função detectou redes sociais: {has_social}")
        
        # Testar busca direta em páginas de contato
        print(f"\n=== Teste direto da busca em páginas de contato ===")
        contact_social = await enrichment_service._scrape_contact_pages_for_social_media(test_url)
        
        print(f"Redes sociais encontradas em páginas de contato:")
        for platform, url in contact_social.items():
            if url:
                print(f"- {platform.capitalize()}: {url}")
        
        if not any(contact_social.values()):
            print("❌ Nenhuma rede social encontrada nas páginas de contato")
        
    except Exception as e:
        print(f"❌ Erro durante o teste: {str(e)}")
        import traceback
        traceback.print_exc()
    
    finally:
        db_session.close()
        # Cleanup - CompanyEnrichmentService não tem método close
        print("Test completed")

if __name__ == "__main__":
    asyncio.run(test_contact_social_integration())