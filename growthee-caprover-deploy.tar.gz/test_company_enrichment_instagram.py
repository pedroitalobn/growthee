import asyncio
import json
import importlib.util
import os

# Import LogService
from api.log_service import LogService

# Import CompanyEnrichmentService directly from services.py
services_path = os.path.join(os.path.dirname(__file__), 'api', 'services.py')
spec = importlib.util.spec_from_file_location("services", services_path)
services = importlib.util.module_from_spec(spec)
spec.loader.exec_module(services)
CompanyEnrichmentService = services.CompanyEnrichmentService

async def test_company_enrichment_instagram():
    """Test the Instagram enrichment functionality of CompanyEnrichmentService"""
    print("\n===== Testing CompanyEnrichmentService Instagram Enrichment =====\n")
    
    # Initialize services
    log_service = LogService()
    company_service = CompanyEnrichmentService(None, log_service)
    
    # Test URLs
    test_urls = [
        "https://www.instagram.com/nike/",
        "https://www.instagram.com/apple/",
        "https://www.instagram.com/microsoft/",
        "https://www.instagram.com/unknown_company_profile/"
    ]
    
    for url in test_urls:
        print(f"\nTesting URL: {url}")
        try:
            # Call the enrichment method
            result = await company_service._enrich_by_instagram(url)
            
            # Print the result
            print(f"Result for {url}:")
            print(json.dumps(result, indent=2))
            
            # Check if we got expected data
            if "error" in result:
                print(f"Error: {result['error']}")
            else:
                print(f"Success! Extracted data for {result.get('instagram', {}).get('username')}")
                print(f"Name: {result.get('name')}")
                print(f"Description: {result.get('description')}")
                print(f"Website: {result.get('website')}")
                print(f"Followers: {result.get('instagram', {}).get('followers_count')}")
        
        except Exception as e:
            print(f"Exception: {str(e)}")

if __name__ == "__main__":
    asyncio.run(test_company_enrichment_instagram())