import asyncio
import json
import os
from dotenv import load_dotenv
from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session

# Carregar variáveis de ambiente
load_dotenv()

async def test_full_firecrawl_flow():
    # Configurar serviços
    log_service = LogService()
    enrichment_service = CompanyEnrichmentService(None, log_service)
    
    # Schema padrão
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "description": "Nome da empresa"},
            "description": {"type": "string", "description": "Descrição da empresa"},
            "industry": {"type": "string", "description": "Setor/indústria da empresa"},
            "founded": {"type": "string", "description": "Ano de fundação"},
            "headquarters": {"type": "string", "description": "Sede da empresa"},
            "website": {"type": "string", "description": "Website da empresa"},
            "size": {"type": "string", "description": "Tamanho da empresa"}
        },
        "required": ["name", "description"]
    }
    
    url = "https://microsoft.com"
    print(f"Testando fluxo completo do Firecrawl para: {url}")
    
    try:
        # Testar o método _scrape_with_firecrawl diretamente
        result = await enrichment_service._scrape_with_firecrawl(url, schema)
        
        print(f"\nResultado do _scrape_with_firecrawl:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
        # Verificar se há erro
        if "error" in result:
            print(f"\nErro encontrado: {result['error']}")
        else:
            # Verificar campos preenchidos
            filled_fields = [k for k, v in result.items() if v and str(v).strip() and k != '_metadata']
            print(f"\nCampos preenchidos: {filled_fields}")
            print(f"Total de campos preenchidos: {len(filled_fields)}")
            
            # Verificar metadados se existirem
            if '_metadata' in result:
                print(f"\nMetadados: {result['_metadata']}")
        
    except Exception as e:
        print(f"Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_full_firecrawl_flow())