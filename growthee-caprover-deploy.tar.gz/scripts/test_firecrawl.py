#!/usr/bin/env python3

import os
import sys
import json
import argparse
from dotenv import load_dotenv

# Adicionar o diretório raiz ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.firecrawl_client import FirecrawlApp

def main():
    # Carregar variáveis de ambiente do arquivo .env
    load_dotenv()
    
    # Configurar argumentos da linha de comando
    parser = argparse.ArgumentParser(description='Testar a API Firecrawl')
    parser.add_argument('--url', type=str, required=True, help='URL para fazer scraping')
    parser.add_argument('--schema', type=str, help='Caminho para arquivo JSON com schema de extração')
    parser.add_argument('--api-key', type=str, help='API key do Firecrawl (opcional, usa env FIRECRAWL_API_KEY por padrão)')
    parser.add_argument('--output', type=str, help='Caminho para salvar o resultado em JSON')
    
    args = parser.parse_args()
    
    # Inicializar o cliente Firecrawl
    firecrawl = FirecrawlApp(api_key=args.api_key)
    
    # Se um schema foi fornecido, usar extract_structured_data
    if args.schema:
        try:
            with open(args.schema, 'r') as f:
                schema = json.load(f)
            
            print(f"Extraindo dados estruturados de {args.url} usando schema...")
            result = firecrawl.extract_structured_data(args.url, schema)
        except Exception as e:
            print(f"Erro ao carregar schema: {e}")
            return
    else:
        # Caso contrário, usar scrape_url
        print(f"Fazendo scraping de {args.url}...")
        result = firecrawl.scrape_url(args.url)
    
    # Exibir o resultado
    print("\nResultado:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    # Salvar o resultado em um arquivo se solicitado
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"\nResultado salvo em {args.output}")

if __name__ == "__main__":
    main()