import os
from dotenv import load_dotenv
import requests

load_dotenv()

# Test DeepSeek API
api_key = os.getenv('DEEPSEEK_API_KEY')
print(f"DeepSeek API Key: {api_key[:10]}...{api_key[-5:] if api_key else 'Not found'}")

if api_key and api_key != "your_deepseek_api_key_here":
    try:
        response = requests.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            json={
                "model": "deepseek-chat",
                "messages": [
                    {"role": "user", "content": "Hello, this is a test. Please respond with 'API is working'"}
                ],
                "max_tokens": 50
            }
        )
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"Response: {result['choices'][0]['message']['content']}")
        else:
            print(f"Error: {response.text}")
    except Exception as e:
        print(f"Error testing DeepSeek API: {e}")
else:
    print("DeepSeek API key not configured properly")

# Test Firecrawl API
firecrawl_key = os.getenv('FIRECRAWL_API_KEY')
print(f"\nFirecrawl API Key: {firecrawl_key[:10]}...{firecrawl_key[-5:] if firecrawl_key else 'Not found'}")