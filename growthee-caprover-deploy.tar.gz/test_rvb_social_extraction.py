#!/usr/bin/env python3
"""
Teste simplificado para extração de redes sociais
"""

import re
import json

def extract_social_media_simple(html_content):
    """Extração simplificada de redes sociais"""
    social_media = {}
    
    # Padrões regex para redes sociais
    patterns = {
        'facebook': r'https?://(?:www\.)?facebook\.com/[\w\.-]+',
        'instagram': r'https?://(?:www\.)?instagram\.com/[\w\.-]+',
        'linkedin': r'https?://(?:www\.)?linkedin\.com/(?:company|in)/[\w\.-]+',
        'twitter': r'https?://(?:www\.)?(?:twitter\.com|x\.com)/[\w\.-]+',
        'youtube': r'https?://(?:www\.)?youtube\.com/(?:channel|c|user)/[\w\.-]+'
    }
    
    # Extrair de JSON-LD
    json_ld_pattern = r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>([\s\S]*?)</script>'
    json_matches = re.findall(json_ld_pattern, html_content, re.IGNORECASE)
    
    print(f"📄 Encontrados {len(json_matches)} blocos JSON-LD")
    
    for i, json_match in enumerate(json_matches):
        try:
            data = json.loads(json_match.strip())
            print(f"  📋 Bloco {i+1}: {type(data).__name__}")
            
            if isinstance(data, dict) and 'sameAs' in data:
                same_as = data['sameAs']
                print(f"    🔗 sameAs encontrado: {same_as}")
                
                if isinstance(same_as, list):
                    for url in same_as:
                        for platform, pattern in patterns.items():
                            if re.search(pattern, url, re.IGNORECASE):
                                social_media[platform] = url
                                print(f"    ✅ {platform.capitalize()}: {url}")
                                break
        except json.JSONDecodeError as e:
            print(f"    ❌ Erro JSON no bloco {i+1}: {e}")
            continue
    
    # Extrair de links HTML
    print(f"\n🔍 Buscando links HTML...")
    for platform, pattern in patterns.items():
        if platform not in social_media:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            if matches:
                social_media[platform] = matches[0]
                print(f"  ✅ {platform.capitalize()} (HTML): {matches[0]}")
    
    return social_media

def main():
    """Função principal de teste"""
    
    # HTML de exemplo com JSON-LD
    html_content = '''
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>RVB - Consultoria em Gestão</title>
    </head>
    <body>
        <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "RVB Consultoria",
            "url": "https://rvb.com.br",
            "sameAs": [
                "https://www.facebook.com/rvbconsultoria",
                "https://www.instagram.com/rvb_consultoria",
                "https://www.linkedin.com/company/rvb-consultoria",
                "https://twitter.com/rvbconsultoria",
                "https://www.youtube.com/channel/UCrvbconsultoria"
            ]
        }
        </script>
        
        <footer>
            <div class="social-links">
                <a href="https://www.facebook.com/rvbconsultoria" target="_blank">Facebook</a>
                <a href="https://www.instagram.com/rvb_consultoria" target="_blank">Instagram</a>
                <a href="https://www.linkedin.com/company/rvb-consultoria" target="_blank">LinkedIn</a>
            </div>
        </footer>
    </body>
    </html>
    '''
    
    print("🔍 Teste de extração de redes sociais do RVB")
    print("=" * 60)
    
    social_media = extract_social_media_simple(html_content)
    
    print(f"\n📊 Resumo das redes sociais extraídas:")
    if social_media:
        for platform, url in social_media.items():
            print(f"  ✅ {platform.capitalize()}: {url}")
        print(f"\n🎯 Total: {len(social_media)} redes sociais encontradas")
    else:
        print("  ❌ Nenhuma rede social encontrada")
    
    print("\n" + "=" * 60)
    print("✅ Teste concluído!")

if __name__ == "__main__":
    main()