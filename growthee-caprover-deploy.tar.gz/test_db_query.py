#!/usr/bin/env python3

import asyncio
from prisma import Prisma
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

async def test_user_query():
    """Test the exact same query used in auth_routes.py"""
    
    # Create a new Prisma instance
    db = Prisma()
    
    try:
        # Connect to database
        print(f"Connecting to database: {os.getenv('DATABASE_URL')}")
        await db.connect()
        print(f"Database connected: {db.is_connected()}")
        
        # Test the exact query from auth_routes.py
        email_to_search = "client@client.com"
        print(f"Searching for user with email: {email_to_search}")
        
        user = await db.user.find_unique(
            where={"email": email_to_search}
        )
        
        print(f"Query result: {user}")
        
        if user:
            print(f"User found:")
            print(f"  - ID: {user.id}")
            print(f"  - Email: {user.email}")
            print(f"  - Full Name: {user.fullName}")
            print(f"  - Is Active: {user.isActive}")
            print(f"  - Password Hash: {user.passwordHash[:20]}...")
        else:
            print("User not found in database")
            
            # Let's also try to list all users to see what's in the database
            print("\nListing all users in database:")
            all_users = await db.user.find_many()
            for u in all_users:
                print(f"  - {u.email} ({u.fullName})")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if db.is_connected():
            await db.disconnect()
            print("Database disconnected")

if __name__ == "__main__":
    asyncio.run(test_user_query())