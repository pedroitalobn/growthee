import requests
import json

# Test registration endpoint
url = "http://localhost:8000/api/v1/auth/register"
data = {
    "email": "testuser2024@example.com",
    "password": "TestPass123",
    "fullName": "New Test User",
    "companyName": "New Test Company"
}

try:
    response = requests.post(url, json=data)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.text}")
    
    if response.status_code == 200:
        result = response.json()
        print(f"\nUser created successfully!")
        print(f"User ID: {result['user']['id']}")
        print(f"Email: {result['user']['email']}")
        print(f"Credits Remaining: {result['user']['credits_remaining']}")
        print(f"Credits Total: {result['user']['credits_total']}")
        print(f"Plan: {result['user']['plan']}")
        print(f"Role: {result['user']['role']}")
except Exception as e:
    print(f"Error: {e}")