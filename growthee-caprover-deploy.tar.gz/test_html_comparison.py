#!/usr/bin/env python3

import os
import sys
import asyncio
import requests
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

# Adicionar o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session
from unittest.mock import Mock

async def compare_html_sources():
    """Compara o HTML capturado pelo Firecrawl vs requests"""
    
    # Mock da sessão do banco
    mock_session = Mock(spec=Session)
    log_service = LogService()
    enrichment_service = CompanyEnrichmentService(mock_session, log_service)
    
    url = "https://rvb.com.br"
    
    print("=== COMPARAÇÃO: HTML Firecrawl vs Requests ===")
    
    # 1. Capturar HTML com Firecrawl
    print("\n1. Capturando HTML com Firecrawl...")
    schema = {"type": "object", "properties": {"name": {"type": "string"}}}
    firecrawl_result = await enrichment_service._scrape_with_firecrawl(url, schema)
    firecrawl_html = firecrawl_result.get('html', '')
    
    print(f"Firecrawl HTML: {len(firecrawl_html)} caracteres")
    
    # 2. Capturar HTML com requests
    print("\n2. Capturando HTML com requests...")
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    response = requests.get(url, headers=headers, timeout=10)
    requests_html = response.text
    
    print(f"Requests HTML: {len(requests_html)} caracteres")
    
    # 3. Testar extração de redes sociais em ambos
    print("\n3. Testando extração de redes sociais...")
    
    # Firecrawl HTML
    firecrawl_social = enrichment_service._extract_social_media_from_html(firecrawl_html)
    print(f"Redes sociais do Firecrawl HTML: {firecrawl_social}")
    
    # Requests HTML
    requests_social = enrichment_service._extract_social_media_from_html(requests_html)
    print(f"Redes sociais do Requests HTML: {requests_social}")
    
    # 4. Comparar conteúdo específico
    print("\n4. Verificando presença de redes sociais no HTML...")
    
    platforms = ['instagram.com', 'linkedin.com', 'facebook.com', 'youtube.com']
    
    for platform in platforms:
        firecrawl_has = platform in firecrawl_html
        requests_has = platform in requests_html
        
        print(f"{platform}:")
        print(f"  Firecrawl: {'✅' if firecrawl_has else '❌'}")
        print(f"  Requests: {'✅' if requests_has else '❌'}")
        
        if requests_has and not firecrawl_has:
            print(f"  ⚠️  {platform} está presente no HTML do requests mas não no Firecrawl!")
    
    # 5. Verificar se há diferenças significativas
    print("\n5. Análise de diferenças...")
    
    if len(firecrawl_html) < len(requests_html) * 0.8:
        print(f"⚠️  HTML do Firecrawl é significativamente menor ({len(firecrawl_html)} vs {len(requests_html)} caracteres)")
    
    # Verificar se o Firecrawl está removendo scripts/links
    firecrawl_links = firecrawl_html.count('<a ')
    requests_links = requests_html.count('<a ')
    
    print(f"Links <a>: Firecrawl={firecrawl_links}, Requests={requests_links}")
    
    if requests_links > firecrawl_links:
        print(f"⚠️  Firecrawl removeu {requests_links - firecrawl_links} links!")
    
    # 6. Mostrar amostras do HTML
    print("\n6. Amostras do HTML...")
    print("\nFirecrawl HTML (primeiros 500 chars):")
    print(firecrawl_html[:500])
    print("\nRequests HTML (primeiros 500 chars):")
    print(requests_html[:500])

if __name__ == "__main__":
    asyncio.run(compare_html_sources())