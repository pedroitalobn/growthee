import asyncio
import os
from prisma import Prisma

async def test_connection():
    print(f"DATABASE_URL from env: {os.getenv('DATABASE_URL')}")
    
    db = Prisma()
    try:
        await db.connect()
        print("Connected to database successfully")
        
        # Test finding user
        user = await db.user.find_unique(
            where={"email": "admin@admin.com"}
        )
        
        if user:
            print(f"User found: {user.email}")
            print(f"Full name: {user.fullName}")
            print(f"Active: {user.isActive}")
        else:
            print("User not found")
            
        # List all users
        all_users = await db.user.find_many()
        print(f"Total users in database: {len(all_users)}")
        for u in all_users:
            print(f"  - {u.email} ({u.fullName})")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        await db.disconnect()

if __name__ == "__main__":
    # Load environment variables
    from dotenv import load_dotenv
    load_dotenv()
    
    asyncio.run(test_connection())