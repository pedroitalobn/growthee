import os
import sys
import json
import unittest
from unittest.mock import patch, MagicMock
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

# Adicionar o diretório raiz ao path para importar módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar os módulos necessários
from api.firecrawl_client import FirecrawlApp

class TestFirecrawlV2Integration(unittest.TestCase):
    """Testes de integração para o Firecrawl V2"""
    
    @patch('api.firecrawl_client.FirecrawlApp.extract_structured_data')
    def test_linkedin_extraction(self, mock_extract):
        """Testar a extração de dados do LinkedIn usando Firecrawl V2"""
        print("\n=== Testando extração de dados do LinkedIn com Firecrawl V2 ===")
        
        # Configurar o mock para simular uma resposta bem-sucedida
        mock_extract.return_value = {
            "name": "Microsoft",
            "tagline": "Empowering every person and every organization on the planet to achieve more.",
            "about": "Microsoft is a technology company that develops, licenses, and supports software products, services, and devices.",
            "website": "https://www.microsoft.com",
            "industry": "Technology",
            "company_size": "10,001+ employees",
            "headquarters": "Redmond, Washington",
            "founded": "1975",
            "specialties": ["Software Development", "Cloud Computing", "Artificial Intelligence"]
        }
        
        # Inicializar o cliente Firecrawl
        firecrawl_client = FirecrawlApp()
        
        # URL de teste do LinkedIn (perfil de empresa)
        url = "https://www.linkedin.com/company/microsoft/"
        
        # Schema para extração de dados
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Nome da empresa"},
                "tagline": {"type": "string", "description": "Slogan ou descrição curta"},
                "about": {"type": "string", "description": "Descrição completa da empresa"},
                "website": {"type": "string", "description": "Website da empresa"},
                "industry": {"type": "string", "description": "Indústria/setor da empresa"},
                "company_size": {"type": "string", "description": "Tamanho da empresa (número de funcionários)"},
                "headquarters": {"type": "string", "description": "Localização da sede"},
                "founded": {"type": "string", "description": "Ano de fundação"},
                "specialties": {"type": "array", "items": {"type": "string"}, "description": "Especialidades da empresa"}
            }
        }
        
        # Testar extração direta com V2
        print("\nTestando extração direta com Firecrawl V2...")
        result = firecrawl_client.extract_structured_data(url, schema, use_deepseek=True)
        
        # Verificar se a extração foi bem-sucedida
        self.assertNotIn("error", result)
        self.assertEqual(result["name"], "Microsoft")
        
        print("\nExtração direta com Firecrawl V2 bem-sucedida!")
        print("\nDados extraídos:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
            
    @patch('api.firecrawl_client.FirecrawlApp.extract_structured_data')
    def test_reddit_extraction(self, mock_extract):
        """Testar a extração de dados do Reddit usando Firecrawl V2"""
        print("\n=== Testando extração de dados do Reddit com Firecrawl V2 ===")
        
        # Configurar o mock para simular uma resposta bem-sucedida
        mock_extract.return_value = {
            "subreddit_name": "Python",
            "description": "News about the programming language Python",
            "subscribers": "1.2M",
            "online_users": "2.5k",
            "created": "2008-01-25",
            "rules": ["Use descriptive titles", "No low-effort posts", "No spam"],
            "top_posts": [
                {"title": "Python 3.10 released", "upvotes": "5.2k", "comments": "342"},
                {"title": "What's new in Python 3.11", "upvotes": "4.8k", "comments": "289"}
            ]
        }
        
        # Inicializar o cliente Firecrawl
        firecrawl_client = FirecrawlApp()
        
        # URL de teste do Reddit (subreddit)
        url = "https://www.reddit.com/r/Python/"
        
        # Schema para extração de dados
        schema = {
            "type": "object",
            "properties": {
                "subreddit_name": {"type": "string", "description": "Nome do subreddit"},
                "description": {"type": "string", "description": "Descrição do subreddit"},
                "subscribers": {"type": "string", "description": "Número de inscritos"},
                "online_users": {"type": "string", "description": "Usuários online"},
                "created": {"type": "string", "description": "Data de criação"},
                "rules": {"type": "array", "items": {"type": "string"}, "description": "Regras do subreddit"},
                "top_posts": {
                    "type": "array", 
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string"},
                            "upvotes": {"type": "string"},
                            "comments": {"type": "string"}
                        }
                    },
                    "description": "Posts em destaque"
                }
            }
        }
        
        # Testar extração direta com V2
        print("\nTestando extração direta com Firecrawl V2...")
        result = firecrawl_client.extract_structured_data(url, schema, use_deepseek=True)
        
        # Verificar se a extração foi bem-sucedida
        self.assertNotIn("error", result)
        self.assertEqual(result["subreddit_name"], "Python")
        
        print("\nExtração direta com Firecrawl V2 bem-sucedida!")
        print("\nDados extraídos:")
        print(json.dumps(result, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    unittest.main()