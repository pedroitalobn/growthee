import asyncio
import json
import os
from dotenv import load_dotenv
from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session

# Carregar variáveis de ambiente
load_dotenv()

async def test_extraction_with_real_content():
    # Configurar serviços
    log_service = LogService()
    enrichment_service = CompanyEnrichmentService(None, log_service)
    
    # Ler o conteúdo markdown real do Firecrawl
    try:
        with open('firecrawl_markdown.txt', 'r', encoding='utf-8') as f:
            markdown_content = f.read()
    except FileNotFoundError:
        print("Arquivo firecrawl_markdown.txt não encontrado")
        return
    
    # Schema padrão
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "description": "Nome da empresa"},
            "description": {"type": "string", "description": "Descrição da empresa"},
            "industry": {"type": "string", "description": "Setor/indústria da empresa"},
            "founded": {"type": "string", "description": "Ano de fundação"},
            "headquarters": {"type": "string", "description": "Sede da empresa"},
            "website": {"type": "string", "description": "Website da empresa"},
            "size": {"type": "string", "description": "Tamanho da empresa"}
        },
        "required": ["name", "description"]
    }
    
    print(f"Testando extração com conteúdo markdown de {len(markdown_content)} caracteres...")
    print(f"Primeiras 200 caracteres: {markdown_content[:200]}...")
    
    # Testar extração
    try:
        result = await enrichment_service._extract_json_from_markdown(markdown_content, schema)
        print(f"\nResultado da extração:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
        # Verificar se algum campo foi preenchido
        filled_fields = [k for k, v in result.items() if v and v.strip()]
        print(f"\nCampos preenchidos: {filled_fields}")
        print(f"Total de campos preenchidos: {len(filled_fields)}")
        
    except Exception as e:
        print(f"Erro durante a extração: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_extraction_with_real_content())