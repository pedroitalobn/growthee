import os
import sys
import unittest
from unittest.mock import patch, MagicMock
import json

# Adicionar o diretório raiz ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.firecrawl_client import FirecrawlApp

class TestFirecrawlApp(unittest.TestCase):
    
    def setUp(self):
        # Configurar o cliente com uma API key de teste
        self.api_key = "test_api_key"
        self.firecrawl = FirecrawlApp(api_key=self.api_key)
    
    def test_init(self):
        # Testar inicialização com API key
        self.assertEqual(self.firecrawl.api_key, self.api_key)
        self.assertEqual(self.firecrawl.base_url, "https://api.firecrawl.dev/v1")
        self.assertEqual(self.firecrawl.headers["Authorization"], f"Bearer {self.api_key}")
        
        # Testar inicialização com variável de ambiente
        with patch.dict(os.environ, {"FIRECRAWL_API_KEY": "env_api_key"}):
            firecrawl = FirecrawlApp()
            self.assertEqual(firecrawl.api_key, "env_api_key")
    
    @patch('requests.post')
    def test_scrape_url(self, mock_post):
        # Configurar o mock para simular uma resposta bem-sucedida
        mock_response = MagicMock()
        mock_response.json.return_value = {"html": "<html>Test</html>", "markdown": "# Test"}
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        # Chamar o método
        result = self.firecrawl.scrape_url("https://example.com")
        
        # Verificar se o método post foi chamado com os parâmetros corretos
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(kwargs["headers"], self.firecrawl.headers)
        self.assertEqual(kwargs["json"]["url"], "https://example.com")
        
        # Verificar o resultado
        self.assertEqual(result, {"html": "<html>Test</html>", "markdown": "# Test"})
    
    @patch('requests.post')
    def test_extract_structured_data(self, mock_post):
        # Configurar o mock para simular uma resposta bem-sucedida
        mock_response = MagicMock()
        mock_response.json.return_value = {"company_name": "Example Corp", "linkedin_url": "https://linkedin.com/company/example"}
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        # Schema de teste
        test_schema = {
            "type": "object",
            "properties": {
                "company_name": {"type": "string"},
                "linkedin_url": {"type": "string"}
            }
        }
        
        # Chamar o método
        result = self.firecrawl.extract_structured_data("https://example.com", test_schema)
        
        # Verificar se o método post foi chamado com os parâmetros corretos
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(kwargs["headers"], self.firecrawl.headers)
        self.assertEqual(kwargs["json"]["url"], "https://example.com")
        self.assertEqual(kwargs["json"]["schema"], test_schema)
        
        # Verificar o resultado
        self.assertEqual(result, {"company_name": "Example Corp", "linkedin_url": "https://linkedin.com/company/example"})
    
    @patch('requests.post')
    def test_extract_structured_data_from_html(self, mock_post):
        # Configurar o mock para simular uma resposta bem-sucedida
        mock_response = MagicMock()
        mock_response.json.return_value = {"company_name": "Example Corp", "linkedin_url": "https://linkedin.com/company/example"}
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        # Schema de teste
        test_schema = {
            "type": "object",
            "properties": {
                "company_name": {"type": "string"},
                "linkedin_url": {"type": "string"}
            }
        }
        
        # HTML de teste
        test_html = "<html><body><h1>Example Corp</h1><a href='https://linkedin.com/company/example'>LinkedIn</a></body></html>"
        
        # Chamar o método
        result = self.firecrawl.extract_structured_data_from_html(test_html, test_schema)
        
        # Verificar se o método post foi chamado com os parâmetros corretos
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(kwargs["headers"], self.firecrawl.headers)
        self.assertEqual(kwargs["json"]["html"], test_html)
        self.assertEqual(kwargs["json"]["schema"], test_schema)
        
        # Verificar o resultado
        self.assertEqual(result, {"company_name": "Example Corp", "linkedin_url": "https://linkedin.com/company/example"})
    
    @patch('requests.post')
    def test_error_handling(self, mock_post):
        # Configurar o mock para simular um erro
        mock_post.side_effect = Exception("API Error")
        
        # Testar scrape_url
        result = self.firecrawl.scrape_url("https://example.com")
        self.assertEqual(result, {"error": "API Error"})
        
        # Testar extract_structured_data
        result = self.firecrawl.extract_structured_data("https://example.com", {})
        self.assertEqual(result, {"error": "API Error"})
        
        # Testar extract_structured_data_from_html
        result = self.firecrawl.extract_structured_data_from_html("<html></html>", {})
        self.assertEqual(result, {"error": "API Error"})

if __name__ == "__main__":
    unittest.main()