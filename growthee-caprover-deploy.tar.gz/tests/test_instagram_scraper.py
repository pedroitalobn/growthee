import unittest
from unittest.mock import patch, MagicMock, AsyncMock
import os
import sys
import json
from typing import Dict, Any

# Adicionar o diretório raiz ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.services.instagram_scraper import InstagramScraperService
from api.log_service import LogService

class TestInstagramScraperService(unittest.IsolatedAsyncioTestCase):
    """Testes para o serviço de scraping do Instagram"""
    
    def setUp(self):
        """Configuração inicial para os testes"""
        self.log_service = MagicMock(spec=LogService)
        self.firecrawl_api_key = "test_api_key"
        self.instagram_scraper = InstagramScraperService(
            log_service=self.log_service,
            firecrawl_api_key=self.firecrawl_api_key
        )
    
    def test_extract_username_from_url(self):
        """Testa a extração de username de diferentes formatos de URL do Instagram"""
        test_cases = [
            ("https://www.instagram.com/username/", "username"),
            ("http://instagram.com/username", "username"),
            ("instagram.com/username/", "username"),
            ("https://www.instagram.com/username?igshid=123456", "username"),
            ("@username", "username"),
            ("https://www.instagram.com/user.name_123/", "user.name_123"),
            ("invalid-url", None),
            (None, None)
        ]
        
        for url, expected in test_cases:
            result = self.instagram_scraper._extract_username_from_url(url)
            self.assertEqual(result, expected, f"Failed for URL: {url}")
    
    def test_convert_to_int(self):
        """Testa a conversão de strings de números para inteiros"""
        test_cases = [
            ("1,234", 1234),
            ("1.2k", 1200),
            ("1,2k", 1200),
            ("5.4M", 5400000),
            ("5,4M", 5400000),
            ("123 followers", 123),
            ("invalid", None),
            (None, None)
        ]
        
        for value, expected in test_cases:
            result = self.instagram_scraper._convert_to_int(value)
            self.assertEqual(result, expected, f"Failed for value: {value}")
    
    @patch("api.services.instagram_scraper.FirecrawlApp")
    async def test_scrape_profile_success(self, mock_firecrawl):
        """Testa o scraping de perfil do Instagram com sucesso"""
        # Mock da resposta do Firecrawl
        mock_instance = mock_firecrawl.return_value
        mock_instance.extract_structured_data.return_value = {
            "data": {
                "username": "testuser",
                "name": "Test User",
                "bio": "This is a test bio",
                "followers": "1.2k",
                "following": "500",
                "posts": "123",
                "website": "https://example.com",
                "email": "test@example.com"
            }
        }
        
        result = await self.instagram_scraper.scrape_profile("https://www.instagram.com/testuser/")
        
        # Verificar se o método foi chamado corretamente
        mock_instance.extract_structured_data.assert_called_once()
        
        # Verificar o resultado
        self.assertTrue(result.get("success"))
        self.assertEqual(result["data"]["username"], "testuser")
        self.assertEqual(result["data"]["name"], "Test User")
        self.assertEqual(result["data"]["followers_count"], 1200)
        self.assertEqual(result["data"]["following_count"], 500)
        self.assertEqual(result["data"]["posts_count"], 123)
    
    @patch("api.services.instagram_scraper.FirecrawlApp")
    async def test_scrape_profile_no_data_key(self, mock_firecrawl):
        """Testa o scraping quando a resposta não tem a chave 'data'"""
        # Mock da resposta do Firecrawl sem a chave 'data'
        mock_instance = mock_firecrawl.return_value
        mock_instance.extract_structured_data.return_value = {
            "username": "testuser",
            "name": "Test User",
            "bio": "This is a test bio",
            "followers": "1.2k",
            "following": "500",
            "posts": "123"
        }
        
        result = await self.instagram_scraper.scrape_profile("https://www.instagram.com/testuser/")
        
        # Verificar o resultado
        self.assertTrue(result.get("success"))
        self.assertEqual(result["data"]["username"], "testuser")
        self.assertEqual(result["data"]["followers_count"], 1200)
    
    @patch("api.services.instagram_scraper.FirecrawlApp")
    async def test_scrape_profile_error(self, mock_firecrawl):
        """Testa o comportamento quando ocorre um erro na extração"""
        # Mock da resposta do Firecrawl com erro
        mock_instance = mock_firecrawl.return_value
        mock_instance.extract_structured_data.return_value = {"error": "API error"}
        
        # Mock do método de fallback
        self.instagram_scraper._fallback_scrape_with_llm = AsyncMock(return_value={
            "success": True,
            "data": {
                "username": "testuser",
                "name": "Test User from LLM"
            }
        })
        
        result = await self.instagram_scraper.scrape_profile("https://www.instagram.com/testuser/")
        
        # Verificar se o fallback foi chamado
        self.instagram_scraper._fallback_scrape_with_llm.assert_called_once()
        
        # Verificar o resultado do fallback
        self.assertTrue(result.get("success"))
        self.assertEqual(result["data"]["name"], "Test User from LLM")
    
    @patch("api.services.instagram_scraper.FirecrawlApp")
    async def test_invalid_instagram_url(self, mock_firecrawl):
        """Testa o comportamento com URL inválida do Instagram"""
        result = await self.instagram_scraper.scrape_profile("https://invalid-url.com")
        
        # Verificar se retornou erro
        self.assertIn("error", result)
        self.assertEqual(result["error"], "Invalid Instagram URL format")
        
        # Verificar que o Firecrawl não foi chamado
        mock_firecrawl.assert_not_called()
    
    @patch("api.services.instagram_scraper.FirecrawlApp")
    async def test_exception_handling(self, mock_firecrawl):
        """Testa o tratamento de exceções durante o scraping"""
        # Mock para lançar exceção
        mock_instance = mock_firecrawl.return_value
        mock_instance.extract_structured_data.side_effect = Exception("Test exception")
        
        result = await self.instagram_scraper.scrape_profile("https://www.instagram.com/testuser/")
        
        # Verificar se retornou erro
        self.assertIn("error", result)
        self.assertIn("Failed to scrape Instagram profile", result["error"])

if __name__ == "__main__":
    unittest.main()