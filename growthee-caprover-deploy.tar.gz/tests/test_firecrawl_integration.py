import os
import sys
import unittest
from unittest.mock import patch, MagicMock
import json
import requests

# Adicionar o diretório raiz ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.firecrawl_client import FirecrawlApp

class TestFirecrawlClient(unittest.TestCase):
    
    def setUp(self):
        # Mock para requests
        self.patcher = patch('api.firecrawl_client.requests')
        self.mock_requests = self.patcher.start()
        
        # Configurar o mock de response
        self.mock_response = MagicMock()
        self.mock_response.status_code = 200
        self.mock_response.json.return_value = {"success": True, "data": {}}
        self.mock_requests.post.return_value = self.mock_response
        
        # Instanciar o cliente FirecrawlApp
        self.firecrawl = FirecrawlApp(api_key="test_api_key")
    
    def tearDown(self):
        self.patcher.stop()
    
    def test_init_with_api_key(self):
        # Testar inicialização com API key
        firecrawl = FirecrawlApp(api_key="test_api_key")
        self.assertEqual(firecrawl.api_key, "test_api_key")
    
    def test_init_with_env_var(self):
        # Testar inicialização com variável de ambiente
        with patch.dict('os.environ', {'FIRECRAWL_API_KEY': 'env_api_key'}):
            firecrawl = FirecrawlApp()
            self.assertEqual(firecrawl.api_key, "env_api_key")
    
    def test_scrape_url(self):
         # Configurar o mock para retornar dados de scraping
         self.mock_response.json.return_value = {
             "success": True,
             "data": {
                 "markdown": "# Example\n\nThis is an example",
                 "html": "<html><body><h1>Example</h1></body></html>"
             }
         }
         
         # Chamar o método
         result = self.firecrawl.scrape_url("https://example.com")
         
         # Verificar se o método post foi chamado com os parâmetros corretos
         self.mock_requests.post.assert_called_once()
         args, kwargs = self.mock_requests.post.call_args
         self.assertEqual(args[0], "https://api.firecrawl.dev/v1/scrape")
         self.assertEqual(kwargs["headers"]["Authorization"], "Bearer test_api_key")
         self.assertEqual(kwargs["json"]["url"], "https://example.com")
         
         # Verificar o resultado
         self.assertEqual(result["data"]["markdown"], "# Example\n\nThis is an example")
         self.assertEqual(result["data"]["html"], "<html><body><h1>Example</h1></body></html>")
    
    def test_extract_structured_data(self):
         # Configurar o mock para retornar dados estruturados
         self.mock_response.json.return_value = {
             "success": True,
             "data": {
                 "company_name": "Example Corp",
                 "linkedin_url": "https://linkedin.com/company/example"
             }
         }
         
         # Schema de teste
         test_schema = {
             "type": "object",
             "properties": {
                 "company_name": {"type": "string"},
                 "linkedin_url": {"type": "string"}
             }
         }
         
         # Chamar o método
         result = self.firecrawl.extract_structured_data("https://example.com", test_schema)
         
         # Verificar se o método post foi chamado com os parâmetros corretos
         self.mock_requests.post.assert_called_once()
         args, kwargs = self.mock_requests.post.call_args
         self.assertEqual(args[0], "https://api.firecrawl.dev/v1/extract")
         self.assertEqual(kwargs["headers"]["Authorization"], "Bearer test_api_key")
         self.assertEqual(kwargs["json"]["url"], "https://example.com")
         self.assertEqual(kwargs["json"]["schema"], test_schema)
         
         # Verificar o resultado
         self.assertEqual(result["data"]["company_name"], "Example Corp")
         self.assertEqual(result["data"]["linkedin_url"], "https://linkedin.com/company/example")
    
    def test_extract_structured_data_from_html(self):
         # Configurar o mock para retornar dados estruturados
         self.mock_response.json.return_value = {
             "success": True,
             "data": {
                 "company_name": "Example Corp",
                 "linkedin_url": "https://linkedin.com/company/example"
             }
         }
         
         # Schema de teste
         test_schema = {
             "type": "object",
             "properties": {
                 "company_name": {"type": "string"},
                 "linkedin_url": {"type": "string"}
             }
         }
         
         # HTML de teste
         test_html = "<html><body><h1>Example Corp</h1></body></html>"
         
         # Chamar o método
         result = self.firecrawl.extract_structured_data_from_html(test_html, test_schema)
         
         # Verificar se o método post foi chamado com os parâmetros corretos
         self.mock_requests.post.assert_called_once()
         args, kwargs = self.mock_requests.post.call_args
         self.assertEqual(args[0], "https://api.firecrawl.dev/v1/extract-from-html")
         self.assertEqual(kwargs["headers"]["Authorization"], "Bearer test_api_key")
         self.assertEqual(kwargs["json"]["html"], test_html)
         self.assertEqual(kwargs["json"]["schema"], test_schema)
         
         # Verificar o resultado
         self.assertEqual(result["data"]["company_name"], "Example Corp")
         self.assertEqual(result["data"]["linkedin_url"], "https://linkedin.com/company/example")
    
    def test_api_error(self):
         # Configurar o mock para retornar erro
         self.mock_response.status_code = 400
         self.mock_response.json.return_value = {
             "success": False,
             "error": "Invalid request"
         }
         
         # Configurar o mock para lançar exceção
         self.mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError("400 Client Error")
         
         # Chamar o método
         result = self.firecrawl.scrape_url("https://example.com")
         
         # Verificar se o resultado contém a chave de erro
         self.assertIn("error", result)
         self.assertTrue("400 Client Error" in result["error"])

if __name__ == "__main__":
    unittest.main()