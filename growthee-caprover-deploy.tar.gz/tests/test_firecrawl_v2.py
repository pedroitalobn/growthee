import os
import sys
import json
from dotenv import load_dotenv

# Adicionar o diretório raiz ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.firecrawl_client import FirecrawlApp

# Carregar variáveis de ambiente
load_dotenv()

def test_firecrawl_v2_scrape():
    """Testa a funcionalidade de scrape da API v2 do Firecrawl"""
    firecrawl = FirecrawlApp()
    
    # Testar scrape_url com a API v2
    result = firecrawl.scrape_url("https://example.com")
    
    print("\n=== Teste de Scrape V2 ===")
    print(f"Status: {'Sucesso' if not result.get('error') else 'Falha'}")
    if result.get('error'):
        print(f"Erro: {result.get('error')}")
    else:
        print(f"Conteúdo obtido: {len(str(result))} caracteres")
        print(f"Formatos disponíveis: {list(result.keys()) if isinstance(result, dict) else 'N/A'}")
    
    return result

def test_firecrawl_v2_extract():
    """Testa a funcionalidade de extração estruturada da API v2 do Firecrawl"""
    firecrawl = FirecrawlApp()
    
    # Definir um schema simples para teste
    schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string"},
            "mainText": {"type": "string"}
        }
    }
    
    # Testar extract_structured_data com a API v2
    result = firecrawl.extract_structured_data(
        url="https://example.com",
        schema=schema,
        prompt="Extract the title and main text from this webpage"
    )
    
    print("\n=== Teste de Extração Estruturada V2 ===")
    print(f"Status: {'Sucesso' if not result.get('error') else 'Falha'}")
    if result.get('error'):
        print(f"Erro: {result.get('error')}")
    else:
        print(f"Dados extraídos: {json.dumps(result, indent=2, ensure_ascii=False)}")
    
    return result

def test_firecrawl_v2_extract_html():
    """Testa a funcionalidade de extração estruturada de HTML da API v2 do Firecrawl"""
    firecrawl = FirecrawlApp()
    
    # HTML simples para teste
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Página de Teste</title>
    </head>
    <body>
        <h1>Título Principal</h1>
        <p>Este é um parágrafo de teste para extração de dados.</p>
        <div class="info">
            <span>Autor: João Silva</span>
            <span>Data: 01/01/2023</span>
        </div>
    </body>
    </html>
    """
    
    # Definir um schema simples para teste
    schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string"},
            "content": {"type": "string"},
            "author": {"type": "string"},
            "date": {"type": "string"}
        }
    }
    
    # Testar extract_structured_data_from_html com a API v2
    result = firecrawl.extract_structured_data_from_html(
        html_content=html_content,
        schema=schema,
        prompt="Extract the title, content, author and date from this HTML"
    )
    
    print("\n=== Teste de Extração Estruturada de HTML V2 ===")
    print(f"Status: {'Sucesso' if not result.get('error') else 'Falha'}")
    if result.get('error'):
        print(f"Erro: {result.get('error')}")
    else:
        print(f"Dados extraídos: {json.dumps(result, indent=2, ensure_ascii=False)}")
    
    return result

if __name__ == "__main__":
    # Executar todos os testes
    scrape_result = test_firecrawl_v2_scrape()
    extract_result = test_firecrawl_v2_extract()
    extract_html_result = test_firecrawl_v2_extract_html()
    
    # Verificar se todos os testes foram bem-sucedidos
    all_success = (
        not scrape_result.get('error') and 
        not extract_result.get('error') and 
        not extract_html_result.get('error')
    )
    
    print("\n=== Resultado Final ===")
    print(f"Status geral: {'Todos os testes passaram' if all_success else 'Alguns testes falharam'}")
    
    # Código de saída para integração com CI/CD
    sys.exit(0 if all_success else 1)