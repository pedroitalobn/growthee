import os
import sys
import json
from dotenv import load_dotenv
import asyncio

# Adicionar o diretório raiz ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.services.hyperbrowser_instagram_scraper import HyperbrowserInstagramScraperService
from api.services.puppeteer_instagram_scraper import PuppeteerInstagramScraperService
from api.log_service import LogService

# Carregar variáveis de ambiente
load_dotenv()

async def test_hyperbrowser_instagram_scraper():
    """Testa o scraper de Instagram usando Hyperbrowser com Firecrawl V2"""
    log_service = LogService()
    scraper = HyperbrowserInstagramScraperService(log_service)
    
    # URL de teste do Instagram
    test_url = "https://www.instagram.com/nasa/"
    
    print("\n=== Teste de Scraper Instagram com Hyperbrowser + Firecrawl V2 ===")
    print(f"URL: {test_url}")
    
    try:
        # Executar o scraper
        result = await scraper.scrape_profile(test_url)
        
        # Verificar o resultado
        if result.get("error"):
            print(f"Erro: {result.get('error')}")
            return {"error": result.get('error')}
        
        # Mostrar os dados extraídos
        print("Dados extraídos:")
        print(f"Username: {result.get('username')}")
        print(f"Nome: {result.get('name')}")
        print(f"Bio: {result.get('bio')[:50]}..." if result.get('bio') else "Bio: N/A")
        print(f"Seguidores: {result.get('followers')}")
        print(f"Seguindo: {result.get('following')}")
        print(f"Posts: {result.get('posts')}")
        print(f"Website: {result.get('website')}")
        print(f"Email: {result.get('email')}")
        print(f"Categoria: {result.get('businessCategory')}")
        print(f"Localização: {result.get('location')}")
        
        return result
    except Exception as e:
        print(f"Erro ao executar o scraper: {e}")
        return {"error": str(e)}

async def test_puppeteer_instagram_scraper():
    """Testa o scraper de Instagram usando Puppeteer com Firecrawl V2"""
    log_service = LogService()
    scraper = PuppeteerInstagramScraperService(log_service)
    
    # URL de teste do Instagram
    test_url = "https://www.instagram.com/nasa/"
    
    print("\n=== Teste de Scraper Instagram com Puppeteer + Firecrawl V2 ===")
    print(f"URL: {test_url}")
    
    try:
        # Executar o scraper
        result = await scraper.scrape_profile(test_url)
        
        # Verificar o resultado
        if result.get("error"):
            print(f"Erro: {result.get('error')}")
            return {"error": result.get('error')}
        
        # Mostrar os dados extraídos
        print("Dados extraídos:")
        print(f"Username: {result.get('username')}")
        print(f"Nome: {result.get('name')}")
        print(f"Bio: {result.get('bio')[:50]}..." if result.get('bio') else "Bio: N/A")
        print(f"Seguidores: {result.get('followers')}")
        print(f"Seguindo: {result.get('following')}")
        print(f"Posts: {result.get('posts')}")
        print(f"Website: {result.get('website')}")
        print(f"Email: {result.get('email')}")
        print(f"Categoria: {result.get('businessCategory')}")
        print(f"Localização: {result.get('location')}")
        
        return result
    except Exception as e:
        print(f"Erro ao executar o scraper: {e}")
        return {"error": str(e)}

async def main():
    """Função principal para executar os testes"""
    # Testar o scraper com Hyperbrowser
    hyperbrowser_result = await test_hyperbrowser_instagram_scraper()
    
    # Testar o scraper com Puppeteer
    puppeteer_result = await test_puppeteer_instagram_scraper()
    
    # Verificar se ambos os testes foram bem-sucedidos
    hyperbrowser_success = not hyperbrowser_result.get("error")
    puppeteer_success = not puppeteer_result.get("error")
    
    print("\n=== Resultado Final ===")
    print(f"Hyperbrowser: {'Sucesso' if hyperbrowser_success else 'Falha'}")
    print(f"Puppeteer: {'Sucesso' if puppeteer_success else 'Falha'}")
    
    # Código de saída para integração com CI/CD
    return 0 if (hyperbrowser_success or puppeteer_success) else 1

if __name__ == "__main__":
    # Executar os testes de forma assíncrona
    exit_code = asyncio.run(main())
    sys.exit(exit_code)