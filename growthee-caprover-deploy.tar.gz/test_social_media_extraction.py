#!/usr/bin/env python3

import os
import sys
import asyncio
import requests
from bs4 import BeautifulSoup

# Adicionar o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session

async def test_social_media_extraction():
    """Testa a extração de redes sociais do HTML"""
    
    # Configurar serviços
    log_service = LogService()
    enrichment_service = CompanyEnrichmentService(None, log_service)
    
    # URL de teste
    url = "https://rvb.com.br"
    
    print("=== TESTE: Extração de Redes Sociais Detalhada ===")
    
    # Capturar HTML com requests
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    response = requests.get(url, headers=headers, timeout=10)
    html_content = response.text
    
    print(f"HTML capturado: {len(html_content)} caracteres")
    
    # Testar extração de redes sociais
    social_media = enrichment_service._extract_social_media_from_html(html_content)
    print(f"Resultado da extração: {social_media}")
    
    # Testar extração de JSON-LD
    json_ld_social = enrichment_service._extract_json_ld_social_media(html_content)
    print(f"JSON-LD social media: {json_ld_social}")
    
    # Buscar manualmente por padrões
    print("\n=== BUSCA MANUAL POR PADRÕES ===")
    
    # Instagram
    if 'instagram.com' in html_content:
        print("✅ Encontrado: instagram.com no HTML")
        # Extrair URLs específicas
        import re
        instagram_pattern = r'https?://(?:www\.)?instagram\.com/[^\s"\'>]+'
        instagram_matches = re.findall(instagram_pattern, html_content)
        print(f"URLs do Instagram encontradas: {instagram_matches}")
    else:
        print("❌ Não encontrado: instagram.com")
    
    # LinkedIn
    if 'linkedin.com' in html_content:
        print("✅ Encontrado: linkedin.com no HTML")
        linkedin_pattern = r'https?://(?:www\.)?linkedin\.com/[^\s"\'>]+'
        linkedin_matches = re.findall(linkedin_pattern, html_content)
        print(f"URLs do LinkedIn encontradas: {linkedin_matches}")
    else:
        print("❌ Não encontrado: linkedin.com")
    
    # Facebook
    if 'facebook.com' in html_content:
        print("✅ Encontrado: facebook.com no HTML")
        facebook_pattern = r'https?://(?:www\.)?facebook\.com/[^\s"\'>]+'
        facebook_matches = re.findall(facebook_pattern, html_content)
        print(f"URLs do Facebook encontradas: {facebook_matches}")
    else:
        print("❌ Não encontrado: facebook.com")
    
    # YouTube
    if 'youtube.com' in html_content:
        print("✅ Encontrado: youtube.com no HTML")
        youtube_pattern = r'https?://(?:www\.)?youtube\.com/[^\s"\'>]+'
        youtube_matches = re.findall(youtube_pattern, html_content)
        print(f"URLs do YouTube encontradas: {youtube_matches}")
    else:
        print("❌ Não encontrado: youtube.com")
    
    # Buscar por links <a> com href
    print("\n=== BUSCA POR LINKS <a> ===")
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Todos os links
    all_links = soup.find_all('a', href=True)
    social_links = []
    
    for link in all_links:
        href = link.get('href', '')
        if any(platform in href for platform in ['instagram.com', 'linkedin.com', 'facebook.com', 'youtube.com']):
            social_links.append(href)
    
    print(f"Links de redes sociais encontrados: {social_links}")
    
    # Buscar por scripts que podem conter URLs
    print("\n=== BUSCA EM SCRIPTS ===")
    scripts = soup.find_all('script')
    script_social_urls = []
    
    for script in scripts:
        if script.string:
            script_content = script.string
            if any(platform in script_content for platform in ['instagram.com', 'linkedin.com', 'facebook.com', 'youtube.com']):
                # Extrair URLs dos scripts
                import re
                urls = re.findall(r'https?://(?:www\.)?(instagram|linkedin|facebook|youtube)\.com/[^\s"\'>]+', script_content)
                script_social_urls.extend(urls)
    
    print(f"URLs de redes sociais em scripts: {script_social_urls}")

if __name__ == "__main__":
    asyncio.run(test_social_media_extraction())