import re

# HTML content from aae.energy (simplified for testing)
html_content = '''https://www.instagram.com/allaboutenergy/ https://www.linkedin.com/company/aae-digital/ http://x.com/allabout_energy https://api.whatsapp.com/send?phone=5511951991009&text=Ol%C3%A1!%20Quero%20mais%20informa%C3%A7%C3%B5es%20sobre%20o%20All%20About%20Energy%202025!'''

# Test regex patterns
patterns = {
    'instagram': r'https?://(?:www\.)?instagram\.com/([a-zA-Z0-9_.]+)/?',
    'linkedin': r'https?://(?:www\.)?linkedin\.com/company/([a-zA-Z0-9-]+)/?',
    'facebook': r'https?://(?:www\.)?facebook\.com/([a-zA-Z0-9.]+)/?',
    'twitter': r'https?://(?:www\.)?(twitter\.com|x\.com)/([a-zA-Z0-9_]+)/?',
    'youtube': r'https?://(?:www\.)?youtube\.com/(?:channel/|c/|user/)?([a-zA-Z0-9_-]+)/?',
    'whatsapp': r'(?:https?://)?(?:wa\.me/|whatsapp\.com/send\?phone=)([0-9+]+)'
}

print("Testing regex patterns on aae.energy social media URLs:")
print("HTML content:", html_content)
print("\nResults:")

for platform, pattern in patterns.items():
    matches = re.findall(pattern, html_content, re.IGNORECASE)
    if matches:
        print(f'{platform}: {matches}')
    else:
        print(f'{platform}: No matches')