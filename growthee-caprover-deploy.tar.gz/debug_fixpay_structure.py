import asyncio
from playwright.async_api import async_playwright

async def debug_fixpay_structure():
    """Script para debugar a estrutura HTML da página da Fixpay"""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)  # Modo visual para debug
        context = await browser.new_context()
        page = await context.new_page()
        
        print("Navegando para a página da Fixpay...")
        await page.goto("https://www.linkedin.com/company/fixpay/")
        await page.wait_for_timeout(3000)
        
        print("\n=== ESTRUTURA HTML COMPLETA ===")
        # Extrair todo o HTML da seção 'about'
        about_section = await page.query_selector('.org-about-us-organization-description')
        if about_section:
            html_content = await about_section.inner_html()
            print("Seção About encontrada:")
            print(html_content[:1000])  # Primeiros 1000 caracteres
        
        print("\n=== BUSCANDO POR TEXTO 'SEDE' ===")
        # Buscar todos os elementos que contenham 'Sede' ou 'Fortaleza'
        sede_elements = await page.query_selector_all('text=/Sede|Fortaleza|Ceará/i')
        for i, element in enumerate(sede_elements[:5]):
            try:
                text = await element.inner_text()
                parent = await element.query_selector('..')
                parent_html = await parent.inner_html() if parent else "No parent"
                print(f"\nElemento {i+1}:")
                print(f"Texto: {text}")
                print(f"Parent HTML: {parent_html[:200]}...")
            except:
                continue
        
        print("\n=== BUSCANDO ESTRUTURAS DT/DD ===")
        # Buscar todas as estruturas dt/dd
        dt_elements = await page.query_selector_all('dt')
        for i, dt in enumerate(dt_elements[:10]):
            try:
                dt_text = await dt.inner_text()
                dd = await dt.query_selector('xpath=following-sibling::dd[1]')
                dd_text = await dd.inner_text() if dd else "No DD found"
                print(f"\nDT/DD {i+1}:")
                print(f"DT: {dt_text}")
                print(f"DD: {dd_text}")
            except:
                continue
        
        print("\n=== BUSCANDO DIVS COM CLASSES ESPECÍFICAS ===")
        # Buscar por classes que possam conter informações da empresa
        selectors_to_test = [
            '.org-about-company-module',
            '.org-about-us-organization-description',
            '.org-top-card-summary-info-list',
            '[data-test-id*="about"]',
            '[data-test-id*="org"]'
        ]
        
        for selector in selectors_to_test:
            elements = await page.query_selector_all(selector)
            if elements:
                print(f"\nEncontrados {len(elements)} elementos para: {selector}")
                for i, element in enumerate(elements[:2]):
                    try:
                        text = await element.inner_text()
                        if 'Fortaleza' in text or 'Ceará' in text or 'Sede' in text:
                            print(f"Elemento {i+1} contém informações de sede:")
                            print(f"Texto: {text[:300]}...")
                            html = await element.inner_html()
                            print(f"HTML: {html[:300]}...")
                    except:
                        continue
        
        await browser.close()

if __name__ == "__main__":
    asyncio.run(debug_fixpay_structure())