import bcrypt

# The hash from database
stored_hash = "$2b$12$92asUyVhAA.dMJPKHlwhYuRSIR2xCi/5arO8tO9D16uZyDRQOz7r6"

# Test passwords
passwords_to_test = ["@Story987", "admin123", "admin", "password"]

for password in passwords_to_test:
    try:
        # Convert string hash to bytes if needed
        hash_bytes = stored_hash.encode('utf-8') if isinstance(stored_hash, str) else stored_hash
        password_bytes = password.encode('utf-8')
        
        result = bcrypt.checkpw(password_bytes, hash_bytes)
        print(f"Password '{password}': {result}")
    except Exception as e:
        print(f"Error testing password '{password}': {e}")

# Also test what the create_superadmin script would generate
print("\nTesting hash generation:")
test_password = "@Story987"
hashed = bcrypt.hashpw(test_password.encode('utf-8'), bcrypt.gensalt())
print(f"Generated hash: {hashed}")
print(f"Verification: {bcrypt.checkpw(test_password.encode('utf-8'), hashed)}")