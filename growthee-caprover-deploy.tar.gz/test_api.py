import requests
import json

# Test the EnrichStory API
url = "http://localhost:8000/api/v1/enrich/company"
data = {"domain": "aae.energy"}

try:
    response = requests.post(url, json=data)
    print(f"Status Code: {response.status_code}")
    print(f"Response Headers: {dict(response.headers)}")
    print(f"Response Body: {response.text}")
    
    if response.status_code == 200:
        result = response.json()
        print("\n=== ENRICHMENT RESULTS ===")
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"\nError: {response.status_code} - {response.text}")
        
except requests.exceptions.ConnectionError:
    print("Error: Could not connect to the server. Make sure it's running on http://localhost:8000")
except Exception as e:
    print(f"Error: {e}")