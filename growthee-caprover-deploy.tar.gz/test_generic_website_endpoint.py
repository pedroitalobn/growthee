import requests
import json

url = "http://localhost:8000/api/v1/scrapp/website/test"
data = {
    "url": "https://example.com",
    "extract_links": True,
    "extract_images": True,
    "use_firecrawl": True,
    "use_crawl4ai": True
}

try:
    response = requests.post(url, json=data)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
except Exception as e:
    print(f"Error: {e}")