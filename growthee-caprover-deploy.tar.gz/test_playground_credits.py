#!/usr/bin/env python3

import requests
import json

# Configuração
BASE_URL = "http://localhost:8000"
EMAIL = "test@test.com"
PASSWORD = "test123"

def test_playground_credits():
    """Testa se o playground está exibindo créditos consumidos corretamente"""
    
    # 1. Login
    login_response = requests.post(f"{BASE_URL}/api/v1/auth/login", json={
        "emailOrUsername": EMAIL,
        "password": PASSWORD
    })
    
    if login_response.status_code != 200:
        print(f"❌ Login falhou: {login_response.status_code} - {login_response.text}")
        return
    
    token = login_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    
    print("✅ Login realizado com sucesso")
    
    # 2. Testar endpoint de enriquecimento de empresa
    company_data = {
        "domain": "google.com"
    }
    
    print("\n🔍 Testando enriquecimento de empresa...")
    company_response = requests.post(
        f"{BASE_URL}/api/v1/enrich/company",
        json=company_data,
        headers=headers
    )
    
    print(f"Status: {company_response.status_code}")
    print(f"Headers de resposta: {dict(company_response.headers)}")
    
    # Verificar se o header x-credits-used está presente
    credits_used = company_response.headers.get('x-credits-used')
    if credits_used:
        print(f"✅ Créditos consumidos: {credits_used}")
    else:
        print("❌ Header 'x-credits-used' não encontrado")
    
    if company_response.status_code == 200:
        print("✅ Enriquecimento de empresa funcionando")
    else:
        print(f"❌ Erro no enriquecimento: {company_response.text}")
    
    # 3. Testar endpoint de enriquecimento de pessoa
    person_data = {
        "name": "John Doe",
        "company": "Google"
    }
    
    print("\n👤 Testando enriquecimento de pessoa...")
    person_response = requests.post(
        f"{BASE_URL}/api/v1/enrich/person",
        json=person_data,
        headers=headers
    )
    
    print(f"Status: {person_response.status_code}")
    print(f"Headers de resposta: {dict(person_response.headers)}")
    
    # Verificar se o header x-credits-used está presente
    credits_used = person_response.headers.get('x-credits-used')
    if credits_used:
        print(f"✅ Créditos consumidos: {credits_used}")
    else:
        print("❌ Header 'x-credits-used' não encontrado")
    
    if person_response.status_code == 200:
        print("✅ Enriquecimento de pessoa funcionando")
    else:
        print(f"❌ Erro no enriquecimento: {person_response.text}")

if __name__ == "__main__":
    test_playground_credits()