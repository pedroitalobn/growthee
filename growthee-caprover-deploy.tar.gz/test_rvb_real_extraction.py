#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste de extração de redes sociais do HTML real do site rvb.com.br
"""

import re
import json
from bs4 import BeautifulSoup

# HTML real do site rvb.com.br (truncado para o essencial)
rvb_html = '''<!DOCTYPE html><html lang="pt-BR"><head>
<meta property="article:publisher" content="https://www.facebook.com/rvbbaloes" />
<meta name="twitter:site" content="@rvbbaloes" />
<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://www.rvb.com.br/","url":"https://www.rvb.com.br/","name":"RVB Balões Infláveis Personalizados com rapidez e qualidade","isPartOf":{"@id":"https://www.rvb.com.br/#website"},"about":{"@id":"https://www.rvb.com.br/#organization"},"primaryImageOfPage":{"@id":"https://www.rvb.com.br/#primaryimage"},"image":{"@id":"https://www.rvb.com.br/#primaryimage"},"thumbnailUrl":"https://www.rvb.com.br/wp-content/uploads/2023/06/rvb-baloes-e-inflaveis-promocionais.png","datePublished":"2016-04-18T15:01:06+00:00","dateModified":"2025-06-01T22:23:14+00:00","description":"Quer sair na frente da concorrência e impulsionar suas vendas com infláveis personalizados? A RVB Balões é a escolha certa!","breadcrumb":{"@id":"https://www.rvb.com.br/#breadcrumb"},"inLanguage":"pt-BR","potentialAction":[{"@type":"ReadAction","target":["https://www.rvb.com.br/"]}]},{"@type":"ImageObject","inLanguage":"pt-BR","@id":"https://www.rvb.com.br/#primaryimage","url":"https://www.rvb.com.br/wp-content/uploads/2023/06/rvb-baloes-e-inflaveis-promocionais.png","contentUrl":"https://www.rvb.com.br/wp-content/uploads/2023/06/rvb-baloes-e-inflaveis-promocionais.png","width":800,"height":480,"caption":"RVB balões e infláveis promocionais personalizados"},{"@type":"BreadcrumbList","@id":"https://www.rvb.com.br/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Início"}]},{"@type":"WebSite","@id":"https://www.rvb.com.br/#website","url":"https://www.rvb.com.br/","name":"RVB Balões Infláveis Personalizados","description":"Fabricante de Infláveis Personalizados. Balões Gigantes para Propaganda.","publisher":{"@id":"https://www.rvb.com.br/#organization"},"alternateName":"RVB Infláveis Personalizados","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.rvb.com.br/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"pt-BR"},{"@type":"Organization","@id":"https://www.rvb.com.br/#organization","name":"RVB Balões Infláveis Personalizados","alternateName":"RVB Balões Infláveis Personalizados","url":"https://www.rvb.com.br/","logo":{"@type":"ImageObject","inLanguage":"pt-BR","@id":"https://www.rvb.com.br/#/schema/logo/image/","url":"https://www.rvb.com.br/wp-content/uploads/2023/08/cropped-Logo-RVB-Baloes-Inflaveis.png","contentUrl":"https://www.rvb.com.br/wp-content/uploads/2023/08/cropped-Logo-RVB-Baloes-Inflaveis.png","width":512,"height":512,"caption":"RVB Balões Infláveis Personalizados"},"image":{"@id":"https://www.rvb.com.br/#/schema/logo/image/"},"sameAs":["https://www.facebook.com/rvbbaloes","https://x.com/rvbbaloes","https://www.instagram.com/rvbbaloes/","https://www.youtube.com/c/rvbbaloes","https://www.linkedin.com/company/rvbbaloes/"]}]}</script>
</head><body></body></html>'''

def extract_social_media_from_html(html_content):
    """Extrai redes sociais do HTML usando múltiplas estratégias"""
    social_media = {}
    
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 1. Extrair de JSON-LD
        json_ld_scripts = soup.find_all('script', type='application/ld+json')
        for script in json_ld_scripts:
            try:
                data = json.loads(script.string)
                
                # Função recursiva para buscar sameAs
                def find_same_as(obj):
                    if isinstance(obj, dict):
                        if 'sameAs' in obj:
                            return obj['sameAs']
                        for value in obj.values():
                            result = find_same_as(value)
                            if result:
                                return result
                    elif isinstance(obj, list):
                        for item in obj:
                            result = find_same_as(item)
                            if result:
                                return result
                    return None
                
                same_as = find_same_as(data)
                if same_as:
                    for url in same_as:
                        platform = identify_social_platform(url)
                        if platform:
                            social_media[platform] = url
                            
            except json.JSONDecodeError:
                continue
        
        # 2. Extrair de meta tags
        meta_tags = soup.find_all('meta')
        for tag in meta_tags:
            content = tag.get('content', '')
            property_name = tag.get('property', '')
            name = tag.get('name', '')
            
            # Facebook
            if 'facebook.com' in content:
                social_media['facebook'] = content
            # Twitter
            elif 'twitter:site' in name and content.startswith('@'):
                social_media['twitter'] = f"https://twitter.com/{content[1:]}"
            elif 'x.com' in content or 'twitter.com' in content:
                social_media['twitter'] = content
        
        return social_media
        
    except Exception as e:
        print(f"Erro na extração: {e}")
        return {}

def identify_social_platform(url):
    """Identifica a plataforma de rede social pela URL"""
    url_lower = url.lower()
    
    if 'facebook.com' in url_lower:
        return 'facebook'
    elif 'instagram.com' in url_lower:
        return 'instagram'
    elif 'linkedin.com' in url_lower:
        return 'linkedin'
    elif 'twitter.com' in url_lower or 'x.com' in url_lower:
        return 'twitter'
    elif 'youtube.com' in url_lower or 'youtu.be' in url_lower:
        return 'youtube'
    elif 'tiktok.com' in url_lower:
        return 'tiktok'
    
    return None

def test_rvb_social_extraction():
    """Testa a extração de redes sociais do HTML real do RVB"""
    print("=== Teste de Extração de Redes Sociais - RVB Real ===")
    
    social_media = extract_social_media_from_html(rvb_html)
    
    print(f"\nRedes sociais encontradas: {len(social_media)}")
    for platform, url in social_media.items():
        print(f"  {platform.capitalize()}: {url}")
    
    # Verificar se encontrou as principais redes sociais
    expected_platforms = ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube']
    found_platforms = list(social_media.keys())
    
    print(f"\nPlataformas esperadas: {expected_platforms}")
    print(f"Plataformas encontradas: {found_platforms}")
    
    missing = [p for p in expected_platforms if p not in found_platforms]
    if missing:
        print(f"Plataformas não encontradas: {missing}")
    else:
        print("✅ Todas as plataformas esperadas foram encontradas!")
    
    return len(social_media) >= 3

if __name__ == "__main__":
    success = test_rvb_social_extraction()
    print(f"\n{'✅ Teste passou!' if success else '❌ Teste falhou!'}")