import asyncio
import sys
import os

# Adicionar o diretório raiz ao path para importações
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.log_service import LogService
from api.services.mock_instagram_scraper import MockInstagramScraperService

async def test_instagram_username_extraction():
    """Testa a extração de dados do Instagram usando diferentes formatos de entrada"""
    log_service = LogService()
    instagram_scraper = MockInstagramScraperService(log_service=log_service)
    
    # Lista de formatos de entrada para testar
    test_inputs = [
        "festivaldocavalo",  # Apenas o nome de usuário
        "@festivaldocavalo",  # Nome de usuário com @
        "https://www.instagram.com/festivaldocavalo",  # URL completa
        "https://www.instagram.com/festivaldocavalo/",  # URL com barra no final
        "https://www.instagram.com/festivaldocavalo?igshid=123456"  # URL com parâmetros
    ]
    
    print("\n===== Testando extração de perfil do Instagram =====\n")
    
    for input_format in test_inputs:
        print(f"\nTestando formato: {input_format}")
        result = await instagram_scraper.scrape_profile(input_format)
        
        if "error" in result:
            print(f"❌ Erro: {result['error']}")
        else:
            profile_data = result.get("data", {})
            print("✅ Sucesso! Dados extraídos:")
            print(f"  - Username: {profile_data.get('username')}")
            print(f"  - Nome: {profile_data.get('name')}")
            print(f"  - Bio: {profile_data.get('bio')}")
            print(f"  - Seguidores: {profile_data.get('followers')} ({profile_data.get('followers_count')})")
            print(f"  - Seguindo: {profile_data.get('following')} ({profile_data.get('following_count')})")
            print(f"  - Posts: {profile_data.get('posts')} ({profile_data.get('posts_count')})")
            print(f"  - Website: {profile_data.get('website')}")

if __name__ == "__main__":
    asyncio.run(test_instagram_username_extraction())