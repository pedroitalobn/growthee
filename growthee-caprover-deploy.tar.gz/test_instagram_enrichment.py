import asyncio
import json
import os
from dotenv import load_dotenv
from api.services.hyperbrowser_instagram_scraper import HyperbrowserInstagramScraperService
from api.services.puppeteer_instagram_scraper import PuppeteerInstagramScraperService
from api.log_service import LogService

# Carregar variáveis de ambiente
load_dotenv()

async def test_instagram_enrichment():
    # Inicializar serviços
    log_service = LogService()
    hyperbrowser_scraper = HyperbrowserInstagramScraperService(log_service)
    puppeteer_scraper = PuppeteerInstagramScraperService(log_service)
    
    # Testar diretamente o serviço de scraping do Instagram
    instagram_urls = [
        "https://www.instagram.com/festivaldocavalo/",
        "@festivaldocavalo",
        "festivaldocavalo"
    ]
    
    for url in instagram_urls:
        print(f"\n===== Testando com URL/username: {url} =====")
        
        # Testar com Hyperbrowser
        print("\n[TESTE COM HYPERBROWSER]")
        hyperbrowser_result = await hyperbrowser_scraper.scrape_profile(url)
        print("Resultado do scraping com Hyperbrowser:")
        print(json.dumps(hyperbrowser_result, indent=2, ensure_ascii=False))
        
        # Testar com Puppeteer
        print("\n[TESTE COM PUPPETEER]")
        puppeteer_result = await puppeteer_scraper.scrape_profile(url)
        print("Resultado do scraping com Puppeteer:")
        print(json.dumps(puppeteer_result, indent=2, ensure_ascii=False))
        
        # Função para exibir dados extraídos
        def print_profile_data(result, service_name):
            if "data" in result:
                data = result["data"]
                print(f"\nInformações extraídas por {service_name} para {data.get('username')}:")
                print(f"Nome: {data.get('name')}")
                print(f"Bio: {data.get('bio')}")
                print(f"Seguidores: {data.get('followers')} ({data.get('followers_count')})")
                print(f"Seguindo: {data.get('following')} ({data.get('following_count')})")
                print(f"Posts: {data.get('posts')} ({data.get('posts_count')})")
                if data.get('website'):
                    print(f"Website: {data.get('website')}")
                if data.get('email'):
                    print(f"Email: {data.get('email')}")
                if data.get('business_category'):
                    print(f"Categoria: {data.get('business_category')}")
                if data.get('location'):
                    print(f"Localização: {data.get('location')}")
            else:
                print(f"Nenhum dado extraído ou erro no scraping com {service_name}.")
                if "error" in result:
                    print(f"Erro: {result.get('error')}")
        
        # Exibir dados extraídos
        print_profile_data(hyperbrowser_result, "Hyperbrowser")
        print_profile_data(puppeteer_result, "Puppeteer")
        
        print("\n" + "=" * 50)


if __name__ == "__main__":
    asyncio.run(test_instagram_enrichment())