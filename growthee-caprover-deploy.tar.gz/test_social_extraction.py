#!/usr/bin/env python3

import asyncio
import requests
from api.enhanced_social_extractor import EnhancedSocialExtractor
from api.log_service import LogService

async def test_aae_energy_social_extraction():
    """Testa a extração de redes sociais do site aae.energy"""
    
    # Configurar log service
    log_service = LogService()
    
    # Baixar HTML do site
    print("Baixando HTML do aae.energy...")
    response = requests.get("https://aae.energy")
    html_content = response.text
    
    print(f"HTML baixado: {len(html_content)} caracteres")
    
    # Testar com EnhancedSocialExtractor
    print("\nTestando com EnhancedSocialExtractor...")
    
    async with EnhancedSocialExtractor(log_service) as extractor:
        result = await extractor.extract_comprehensive_social_media(html_content, "https://aae.energy")
        
        print(f"\nResultados da extração:")
        print(f"Tipo do resultado: {type(result)}")
        print(f"Resultado completo: {result}")
        
        # Acessar dados da estrutura correta
        extraction_summary = result.get('extraction_summary', {})
        print(f"Extraction Summary: {extraction_summary}")
        
        print(f"\nRedes sociais encontradas:")
        social_media = result.get('social_media', {})
        for platform, data in social_media.items():
            if data and data.get('primary_url'):
                print(f"  {platform.upper()}:")
                print(f"    URL Principal: {data.get('primary_url')}")
                print(f"    Total encontrado: {data.get('total_found', 0)}")
                print(f"    Melhor confiança: {data.get('best_confidence', 0)}")
                print(f"    Todas as URLs: {data.get('urls', [])}")
        
        print(f"\nInformações de contato:")
        contact_info = result.get('contact_info', {})
        for contact_type, contacts in contact_info.items():
            if contacts:
                print(f"  {contact_type}: {contacts}")
    
    # Verificar se encontrou as redes sociais esperadas
    expected_urls = [
        "https://www.instagram.com/allaboutenergy/",
        "https://www.linkedin.com/company/aae-digital/"
    ]
    
    found_urls = []
    social_media = result.get('social_media', {})
    for platform, data in social_media.items():
        if data and data.get('urls'):
            found_urls.extend(data.get('urls', []))
    
    print(f"\n=== ANÁLISE ===\n")
    
    # Normalizar URLs (remover barra final para comparação)
    def normalize_url(url):
        return url.rstrip('/')
    
    normalized_expected = [normalize_url(url) for url in expected_urls]
    normalized_found = [normalize_url(url) for url in found_urls]
    
    print(f"URLs esperadas: {expected_urls}")
    print(f"URLs encontradas: {found_urls}")
    
    for i, expected_url in enumerate(expected_urls):
        normalized_url = normalized_expected[i]
        if normalized_url in normalized_found:
            print(f"✅ ENCONTRADO: {expected_url}")
        else:
            print(f"❌ NÃO ENCONTRADO: {expected_url}")
    
    # Testar também busca manual no HTML
    print(f"\n=== BUSCA MANUAL NO HTML ===\n")
    import re
    
    # Padrões para buscar redes sociais
    patterns = {
        'instagram': r'https?://(?:www\.)?instagram\.com/[^\s"\'>]+',
        'linkedin': r'https?://(?:www\.)?linkedin\.com/[^\s"\'>]+',
        'facebook': r'https?://(?:www\.)?facebook\.com/[^\s"\'>]+',
        'twitter': r'https?://(?:www\.)?(?:twitter|x)\.com/[^\s"\'>]+',
        'youtube': r'https?://(?:www\.)?youtube\.com/[^\s"\'>]+'
    }
    
    for platform, pattern in patterns.items():
        matches = re.findall(pattern, html_content, re.IGNORECASE)
        if matches:
            print(f"{platform.upper()}: {matches}")
        else:
            print(f"{platform.upper()}: Não encontrado")

if __name__ == "__main__":
    asyncio.run(test_aae_energy_social_extraction())