import asyncio
import requests
import json
from prisma import Prisma

async def test_api_keys():
    # Primeiro, vamos verificar se há usuários no banco
    db = Prisma()
    await db.connect()
    
    try:
        users = await db.user.find_many()
        print(f'Usuários encontrados: {len(users)}')
        
        if users:
            user = users[0]
            print(f'Testando com usuário: {user.email} (ID: {user.id})')
            
            # Verificar API keys existentes
            api_keys = await db.apikey.find_many(where={'userId': user.id})
            print(f'API keys existentes: {len(api_keys)}')
            
            for key in api_keys:
                print(f'  - {key.name}: {key.key[:10]}... (ativo: {key.is_active})')
                
        else:
            print('Nenhum usuário encontrado no banco')
            
    except Exception as e:
        print(f'Erro ao verificar banco: {e}')
    finally:
        await db.disconnect()
    
    # Agora vamos testar o endpoint HTTP
    print('\n--- Testando endpoint HTTP ---')
    
    # Primeiro fazer login para obter token
    login_data = {
        'emailOrUsername': 'test@test.com',
        'password': 'test123'
    }
    
    try:
        response = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
        print(f'Login status: {response.status_code}')
        
        if response.status_code == 200:
            token = response.json().get('access_token')
            print(f'Token obtido: {token[:20]}...')
            
            # Testar criação de API key
            headers = {'Authorization': f'Bearer {token}'}
            api_key_data = {'name': 'Test Key'}
            
            response = requests.post('http://localhost:8000/api/v1/auth/api-keys', 
                                   json=api_key_data, headers=headers)
            print(f'Criação API key status: {response.status_code}')
            print(f'Response: {response.text}')
            
            # Testar listagem de API keys
            response = requests.get('http://localhost:8000/api/v1/auth/api-keys', headers=headers)
            print(f'Listagem API keys status: {response.status_code}')
            print(f'Response: {response.text}')
            
        else:
            print(f'Erro no login: {response.text}')
            
    except Exception as e:
        print(f'Erro na requisição HTTP: {e}')

if __name__ == '__main__':
    asyncio.run(test_api_keys())