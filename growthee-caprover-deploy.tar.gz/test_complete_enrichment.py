#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste completo do sistema de enriquecimento de empresas
Testa a API real com o site rvb.com.br
"""

import requests
import json
import time

def test_company_enrichment_api():
    """Testa a API de enriquecimento de empresas"""
    print("=== Teste Completo da API de Enriquecimento ===")
    
    # URL da API local
    api_url = "http://localhost:8000/api/v1/enrich/company"
    
    # Dados de teste
    test_data = {
        "name": "RVB Balões",
        "domain": "rvb.com.br",
        "region": "Brazil",
        "country": "BR"
    }
    
    print(f"\nTestando com: {test_data}")
    
    try:
        # Fazer a requisição
        print("\nFazendo requisição para a API...")
        response = requests.post(api_url, json=test_data, timeout=60)
        
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("\n✅ Resposta da API:")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
            # Verificar se encontrou redes sociais
            social_media = result.get('social_media', [])
            print(f"\nRedes sociais encontradas: {len(social_media)}")
            
            # Se social_media é uma lista, verificar cada item
            if isinstance(social_media, list):
                found_platforms = []
                for item in social_media:
                    if isinstance(item, dict) and 'platform' in item:
                        platform = item['platform'].lower()
                        url = item.get('url', '')
                        found_platforms.append(platform)
                        print(f"✅ {platform.capitalize()}: {url}")
                
                print(f"Plataformas encontradas: {found_platforms}")
                
                expected_platforms = ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube']
                missing = [p for p in expected_platforms if p not in found_platforms]
                if missing:
                    print(f"⚠️  Plataformas não encontradas: {missing}")
                else:
                    print("✅ Todas as principais plataformas foram encontradas!")
            else:
                # Se for dict (formato antigo), usar o código original
                found_platforms = list(social_media.keys())
                print(f"Plataformas encontradas: {found_platforms}")
            
            # Verificar outros dados
            if result.get('company_name'):
                print(f"✅ Nome da empresa: {result['company_name']}")
            if result.get('description'):
                print(f"✅ Descrição encontrada: {len(result['description'])} caracteres")
            if result.get('industry'):
                print(f"✅ Setor: {result['industry']}")
            
            return len(social_media) >= 3
            
        else:
            print(f"❌ Erro na API: {response.status_code}")
            print(f"Resposta: {response.text}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Erro: Não foi possível conectar à API. Verifique se o servidor está rodando.")
        return False
    except requests.exceptions.Timeout:
        print("❌ Erro: Timeout na requisição.")
        return False
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")
        return False

def check_api_health():
    """Verifica se a API está rodando"""
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        return response.status_code == 200
    except:
        return False

if __name__ == "__main__":
    print("Verificando se a API está rodando...")
    
    if not check_api_health():
        print("❌ API não está rodando. Inicie o servidor com: uvicorn api.main:app --reload")
        exit(1)
    
    print("✅ API está rodando!")
    
    success = test_company_enrichment_api()
    print(f"\n{'✅ Teste completo passou!' if success else '❌ Teste completo falhou!'}")