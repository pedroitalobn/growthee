#!/usr/bin/env python3

import os
import sys
import asyncio
from dotenv import load_dotenv

# Adicionar o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

load_dotenv()

from api.log_service import LogService
from api.services import CompanyEnrichmentService
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

async def test_social_extraction():
    """Testa a extração de redes sociais do site rvb.com.br após as correções"""
    
    # Configurar logging
    log_service = LogService()
    
    # Configurar banco de dados (mock)
    engine = create_engine("sqlite:///:memory:")
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db_session = SessionLocal()
    
    try:
        # Criar serviço de enriquecimento
        enrichment_service = CompanyEnrichmentService(db_session, log_service)
        
        print("\n=== TESTE DE EXTRAÇÃO DE REDES SOCIAIS - RVB.COM.BR ===")
        print("Testando após correções na função _extract_social_media_from_html")
        
        # Testar extração de redes sociais do site principal
        print("\n1. Testando extração da página principal...")
        result = await enrichment_service._scrape_company_website("https://rvb.com.br")
        
        print(f"\nResultado do scraping:")
        print(f"- Sucesso: {result.get('success', False)}")
        print(f"- Fonte: {result.get('source', 'N/A')}")
        
        social_media = result.get('social_media', {})
        print(f"\nRedes sociais encontradas:")
        for platform, url in social_media.items():
            if url:
                print(f"- {platform}: {url}")
        
        if not any(social_media.values()):
            print("❌ Nenhuma rede social encontrada na página principal")
            
            # Testar páginas de contato
            print("\n2. Testando extração de páginas de contato...")
            contact_result = await enrichment_service._scrape_contact_pages_for_social_media("https://rvb.com.br")
            
            print(f"\nResultado do scraping de contato:")
            print(f"- Sucesso: {contact_result.get('success', False)}")
            print(f"- Páginas raspadas: {contact_result.get('pages_scraped', 0)}")
            
            contact_social = contact_result.get('social_media', {})
            print(f"\nRedes sociais encontradas em páginas de contato:")
            for platform, url in contact_social.items():
                if url:
                    print(f"- {platform}: {url}")
                    
            if not any(contact_social.values()):
                print("❌ Nenhuma rede social encontrada nas páginas de contato")
        else:
            print("✅ Redes sociais encontradas com sucesso!")
            
        # Teste direto com HTML conhecido
        print("\n3. Testando extração com HTML de exemplo (JSON-LD)...")
        
        html_example = '''
        <html>
        <head>
            <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@type": "Organization",
                "name": "RVB Sistemas",
                "url": "https://rvb.com.br",
                "sameAs": [
                    "https://www.facebook.com/rvbsistemas",
                    "https://www.instagram.com/rvbsistemas",
                    "https://www.linkedin.com/company/rvb-sistemas",
                    "https://twitter.com/rvbsistemas",
                    "https://www.youtube.com/channel/UCrvbsistemas"
                ]
            }
            </script>
        </head>
        <body>
            <h1>RVB Sistemas</h1>
        </body>
        </html>
        '''
        
        direct_result = enrichment_service._extract_social_media_from_html(html_example)
        print(f"\nRedes sociais extraídas do HTML de exemplo:")
        for platform, url in direct_result.items():
            if url:
                print(f"- {platform}: {url}")
                
        if any(direct_result.values()):
            print("✅ Extração de JSON-LD funcionando corretamente!")
        else:
            print("❌ Falha na extração de JSON-LD")
            
    except Exception as e:
        print(f"❌ Erro durante o teste: {str(e)}")
        import traceback
        traceback.print_exc()
    
    finally:
        db_session.close()
        print("✅ Teste concluído com sucesso!")

if __name__ == "__main__":
    asyncio.run(test_social_extraction())