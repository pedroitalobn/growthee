#!/usr/bin/env python3

import asyncio
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session
from unittest.mock import Mock

async def test_firecrawl_html_processing():
    """Testa se a função _scrape_with_firecrawl está processando o HTML corretamente"""
    
    # Mock da sessão do banco
    mock_session = Mock(spec=Session)
    log_service = LogService()
    
    # Criar instância do serviço
    enrichment_service = CompanyEnrichmentService(mock_session, log_service)
    
    # Schema de teste para redes sociais
    test_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "description": {"type": "string"},
            "industry": {"type": "string"},
            "instagram": {
                "type": "object",
                "properties": {
                    "url": {"type": "string"},
                    "username": {"type": "string"}
                }
            },
            "linkedin_data": {
                "type": "object",
                "properties": {
                    "url": {"type": "string"},
                    "company_name": {"type": "string"}
                }
            },
            "whatsapp": {
                "type": "object",
                "properties": {
                    "url": {"type": "string"},
                    "number": {"type": "string"}
                }
            },
            "facebook": {
                "type": "object",
                "properties": {
                    "url": {"type": "string"},
                    "page_name": {"type": "string"}
                }
            },
            "twitter": {
                "type": "object",
                "properties": {
                    "url": {"type": "string"},
                    "handle": {"type": "string"}
                }
            },
            "youtube": {
                "type": "object",
                "properties": {
                    "url": {"type": "string"},
                    "channel_name": {"type": "string"}
                }
            }
        }
    }
    
    print("=== TESTE: Processamento HTML no Firecrawl ===")
    print(f"URL de teste: rvb.com.br")
    print(f"Schema: {list(test_schema['properties'].keys())}")
    print()
    
    try:
        # Testar a função _scrape_with_firecrawl
        result = await enrichment_service._scrape_with_firecrawl(
            "https://rvb.com.br", 
            test_schema
        )
        
        print("=== RESULTADO DO FIRECRAWL ===")
        print(f"Tipo do resultado: {type(result)}")
        print(f"Chaves encontradas: {list(result.keys()) if isinstance(result, dict) else 'N/A'}")
        print()
        
        if result and not result.get('error'):
            print("=== DADOS EXTRAÍDOS DO MARKDOWN (VIA LLM) ===")
            for key, value in result.items():
                if key != 'html':  # Não mostrar o HTML completo
                    print(f"{key}: {value}")
            print()
            
            # Verificar se o HTML está presente
            html_content = result.get('html')
            if html_content:
                print("=== HTML CAPTURADO ===")
                print(f"Tamanho do HTML: {len(html_content)} caracteres")
                print(f"Primeiros 500 caracteres: {html_content[:500]}...")
                print()
                
                # Testar extração de redes sociais do HTML
                print("=== TESTE: Extração de Redes Sociais do HTML ===")
                html_social_media = enrichment_service._extract_social_media_from_html(html_content)
                print(f"Redes sociais encontradas no HTML: {html_social_media}")
                print()
                
                # Verificar se há diferenças entre markdown e HTML
                print("=== COMPARAÇÃO: Markdown vs HTML ===")
                markdown_social = {
                    'instagram': result.get('instagram'),
                    'linkedin_data': result.get('linkedin_data'),
                    'whatsapp': result.get('whatsapp'),
                    'facebook': result.get('facebook'),
                    'twitter': result.get('twitter'),
                    'youtube': result.get('youtube')
                }
                
                print(f"Redes sociais do Markdown (LLM): {markdown_social}")
                print(f"Redes sociais do HTML (Regex): {html_social_media}")
                
                # Verificar se o HTML tem mais informações
                html_has_more = any(html_social_media.values()) and not any(
                    v for v in markdown_social.values() if v
                )
                
                if html_has_more:
                    print("\n⚠️  PROBLEMA IDENTIFICADO: HTML tem redes sociais que o LLM não extraiu do markdown!")
                    print("Isso indica que a função _scrape_with_firecrawl não está usando o HTML como fallback.")
                else:
                    print("\n✅ Extração consistente entre markdown e HTML.")
                    
            else:
                print("❌ HTML não foi capturado pelo Firecrawl")
                
        else:
            print(f"❌ Erro no Firecrawl: {result.get('error', 'Erro desconhecido')}")
            
    except Exception as e:
        print(f"❌ Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_firecrawl_html_processing())