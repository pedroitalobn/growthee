#!/usr/bin/env python3

import asyncio
import json
from unittest.mock import Mock
from api.services import CompanyEnrichmentService
from api.log_service import LogService

async def debug_full_enrichment_flow():
    """Debug completo do fluxo de enriquecimento"""
    
    # Setup
    log_service = LogService()
    db_session = Mock()
    service = CompanyEnrichmentService(db_session, log_service)
    
    # Dados de teste
    test_data = {
        "domain": "microsoft.com"
    }
    
    print("=== DEBUGGING FULL ENRICHMENT FLOW ===")
    print(f"Input data: {test_data}")
    print()
    
    try:
        # Executar enriquecimento completo
        result = await service.enrich_company(test_data)
        
        print("=== ENRICHMENT RESULT ===")
        print(f"Result type: {type(result)}")
        print(f"Result keys: {list(result.keys()) if isinstance(result, dict) else 'Not a dict'}")
        print()
        
        # Verificar se há enriched_data
        if 'enriched_data' in result:
            enriched_data = result['enriched_data']
            print("=== ENRICHED_DATA ANALYSIS ===")
            print(f"Enriched data type: {type(enriched_data)}")
            print(f"Enriched data keys: {list(enriched_data.keys()) if isinstance(enriched_data, dict) else 'Not a dict'}")
            print()
            
            if isinstance(enriched_data, dict):
                print("=== ENRICHED_DATA CONTENT ===")
                for key, value in enriched_data.items():
                    print(f"{key}: {value} (type: {type(value)})")
                print()
                
                # Verificar campos específicos esperados pela API
                expected_fields = ['name', 'description', 'industry', 'size', 'founded', 'headquarters', 'website', 'linkedin', 'employees']
                print("=== EXPECTED FIELDS CHECK ===")
                for field in expected_fields:
                    value = enriched_data.get(field)
                    status = "✓ PRESENT" if value and str(value).strip() not in ['', 'Unknown', 'N/A', 'null'] else "✗ MISSING/EMPTY"
                    print(f"{field}: {status} (value: {value})")
                print()
        else:
            print("❌ NO 'enriched_data' field in result!")
            print()
        
        # Verificar metadados
        if 'metadata' in result:
            metadata = result['metadata']
            print("=== METADATA ANALYSIS ===")
            print(f"Metadata: {json.dumps(metadata, indent=2)}")
            print()
        
        # Simular o que a API faria
        print("=== API SIMULATION ===")
        if 'enriched_data' in result:
            api_response = {
                "name": result['enriched_data'].get('name'),
                "description": result['enriched_data'].get('description'),
                "industry": result['enriched_data'].get('industry'),
                "size": result['enriched_data'].get('size'),
                "founded": result['enriched_data'].get('founded'),
                "headquarters": result['enriched_data'].get('headquarters'),
                "website": result['enriched_data'].get('website'),
                "linkedin": result['enriched_data'].get('linkedin'),
                "employees": result['enriched_data'].get('employees'),
                "social_media": result['enriched_data'].get('social_media', {})
            }
            print("Simulated API response:")
            print(json.dumps(api_response, indent=2))
            
            # Verificar se todos os campos são nulos
            non_null_fields = [k for k, v in api_response.items() if v is not None and str(v).strip() not in ['', 'Unknown', 'N/A', 'null']]
            print(f"\nNon-null fields: {non_null_fields}")
            print(f"Total non-null fields: {len(non_null_fields)}")
        else:
            print("Cannot simulate API response - no enriched_data")
        
    except Exception as e:
        print(f"❌ Error during enrichment: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(debug_full_enrichment_flow())