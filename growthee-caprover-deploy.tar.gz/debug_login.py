import asyncio
from prisma import Prisma
import bcrypt

async def debug_login():
    db = Prisma()
    await db.connect()
    
    try:
        # Find user
        user = await db.user.find_unique(
            where={"email": "admin@admin.com"}
        )
        
        if user:
            print(f"User found: {user.email}")
            print(f"Full name: {user.fullName}")
            print(f"Password hash type: {type(user.passwordHash)}")
            print(f"Password hash: {user.passwordHash}")
            print(f"Is active: {user.isActive}")
            
            # Test password verification
            test_password = "@Story987"
            print(f"\nTesting password: {test_password}")
            
            # Method 1: Direct encoding
            try:
                result1 = bcrypt.checkpw(test_password.encode('utf-8'), user.passwordHash.encode('utf-8'))
                print(f"Method 1 (direct encode): {result1}")
            except Exception as e:
                print(f"Method 1 error: {e}")
            
            # Method 2: Check if string first
            try:
                password_hash = user.passwordHash.encode('utf-8') if isinstance(user.passwordHash, str) else user.passwordHash
                result2 = bcrypt.checkpw(test_password.encode('utf-8'), password_hash)
                print(f"Method 2 (conditional encode): {result2}")
            except Exception as e:
                print(f"Method 2 error: {e}")
            
            # Method 3: Raw comparison with stored hash
            stored_hash = "$2b$12$92asUyVhAA.dMJPKHlwhYuRSIR2xCi/5arO8tO9D16uZyDRQOz7r6"
            try:
                result3 = bcrypt.checkpw(test_password.encode('utf-8'), stored_hash.encode('utf-8'))
                print(f"Method 3 (known good hash): {result3}")
            except Exception as e:
                print(f"Method 3 error: {e}")
                
        else:
            print("User not found")
            
    finally:
        await db.disconnect()

if __name__ == "__main__":
    asyncio.run(debug_login())