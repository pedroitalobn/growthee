#!/usr/bin/env python3

import requests
import re
from bs4 import BeautifulSoup
import json

def analyze_static_html():
    """Analisa o HTML estático do site rvb.com.br para comparar com o Firecrawl"""
    
    print("=== TESTE: Análise do HTML Estático vs Firecrawl ===")
    print(f"URL de teste: https://rvb.com.br")
    print()
    
    try:
        # Fazer requisição HTTP direta
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        response = requests.get('https://rvb.com.br', headers=headers, timeout=30)
        response.raise_for_status()
        
        html_content = response.text
        
        print("=== ANÁLISE DO HTML ESTÁTICO ===")
        print(f"Status Code: {response.status_code}")
        print(f"Tamanho do HTML: {len(html_content)} caracteres")
        print()
        
        # Parse com BeautifulSoup
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Buscar por padrões de redes sociais no HTML
        social_patterns = {
            'Instagram': [
                r'instagram\.com/[\w\.-]+',
                r'@[\w\.-]+.*instagram',
                r'instagram.*@[\w\.-]+'
            ],
            'LinkedIn': [
                r'linkedin\.com/company/[\w\.-]+',
                r'linkedin\.com/in/[\w\.-]+',
                r'br\.linkedin\.com/[\w\.-]+'
            ],
            'WhatsApp': [
                r'wa\.me/[\d\+\-\s]+',
                r'whatsapp.*[\d\+\-\s\(\)]{8,}',
                r'api\.whatsapp\.com/send\?phone=[\d\+]+'
            ],
            'Facebook': [
                r'facebook\.com/[\w\.-]+',
                r'fb\.com/[\w\.-]+'
            ],
            'Twitter': [
                r'twitter\.com/[\w\.-]+',
                r'x\.com/[\w\.-]+'
            ],
            'YouTube': [
                r'youtube\.com/[\w\.-]+',
                r'youtu\.be/[\w\.-]+'
            ]
        }
        
        found_social = {}
        
        for platform, patterns in social_patterns.items():
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, html_content, re.IGNORECASE)
                matches.extend(found)
            
            if matches:
                found_social[platform] = list(set(matches))  # Remove duplicatas
                print(f"✅ {platform}: {found_social[platform]}")
            else:
                print(f"❌ {platform}: Não encontrado")
        
        print()
        
        # Buscar por links específicos
        print("=== BUSCA POR LINKS <a> ===")
        links = soup.find_all('a', href=True)
        social_links = []
        
        for link in links:
            href = link.get('href', '').lower()
            if any(social in href for social in ['instagram', 'linkedin', 'facebook', 'twitter', 'youtube', 'whatsapp']):
                social_links.append({
                    'href': link.get('href'),
                    'text': link.get_text(strip=True),
                    'title': link.get('title', '')
                })
        
        if social_links:
            print(f"🔗 Links de redes sociais encontrados: {len(social_links)}")
            for link in social_links:
                print(f"   - {link['href']} (texto: '{link['text']}')") 
        else:
            print("❌ Nenhum link de rede social encontrado")
        
        print()
        
        # Buscar por scripts que podem carregar redes sociais
        print("=== BUSCA POR SCRIPTS ===")
        scripts = soup.find_all('script')
        social_scripts = []
        
        for script in scripts:
            script_content = script.get_text() if script.string else ''
            if any(social in script_content.lower() for social in ['instagram', 'linkedin', 'facebook', 'twitter', 'youtube', 'whatsapp']):
                social_scripts.append(script_content[:200] + '...' if len(script_content) > 200 else script_content)
        
        if social_scripts:
            print(f"📜 Scripts com referências a redes sociais: {len(social_scripts)}")
            for i, script in enumerate(social_scripts[:3]):  # Mostrar apenas os primeiros 3
                print(f"   Script {i+1}: {script}")
        else:
            print("❌ Nenhum script com referências a redes sociais")
        
        print()
        
        # Buscar por JSON-LD
        print("=== BUSCA POR JSON-LD ===")
        json_ld_scripts = soup.find_all('script', type='application/ld+json')
        
        if json_ld_scripts:
            print(f"📋 JSON-LD encontrado: {len(json_ld_scripts)} blocos")
            for i, script in enumerate(json_ld_scripts):
                try:
                    json_data = json.loads(script.get_text())
                    print(f"   JSON-LD {i+1}: {json.dumps(json_data, indent=2)[:300]}...")
                except json.JSONDecodeError:
                    print(f"   JSON-LD {i+1}: Erro ao parsear JSON")
        else:
            print("❌ Nenhum JSON-LD encontrado")
        
        print()
        
        # Buscar por meta tags
        print("=== BUSCA POR META TAGS ===")
        meta_tags = soup.find_all('meta')
        social_meta = []
        
        for meta in meta_tags:
            content = meta.get('content', '').lower()
            name = meta.get('name', '').lower()
            property_attr = meta.get('property', '').lower()
            
            if any(social in content or social in name or social in property_attr 
                   for social in ['instagram', 'linkedin', 'facebook', 'twitter', 'youtube', 'whatsapp']):
                social_meta.append({
                    'name': meta.get('name', ''),
                    'property': meta.get('property', ''),
                    'content': meta.get('content', '')
                })
        
        if social_meta:
            print(f"🏷️ Meta tags com referências a redes sociais: {len(social_meta)}")
            for meta in social_meta:
                print(f"   - {meta}")
        else:
            print("❌ Nenhuma meta tag com referências a redes sociais")
        
        print()
        
        # Buscar por texto específico
        print("=== BUSCA POR TEXTO ESPECÍFICO ===")
        page_text = soup.get_text().lower()
        social_keywords = ['instagram', 'linkedin', 'whatsapp', 'facebook', 'twitter', 'youtube']
        
        for keyword in social_keywords:
            if keyword in page_text:
                # Encontrar contexto
                start = page_text.find(keyword)
                context = page_text[max(0, start-50):start+50]
                print(f"🔍 '{keyword}' encontrado no texto: ...{context}...")
            else:
                print(f"❌ '{keyword}': Não encontrado no texto")
                
    except Exception as e:
        print(f"❌ Erro durante a análise: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    analyze_static_html()