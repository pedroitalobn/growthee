import asyncio
import os
import json
from dotenv import load_dotenv

load_dotenv()

async def test_deepseek_extraction():
    """Testa a extração JSON usando DeepSeek diretamente"""
    import httpx
    
    deepseek_api_key = os.getenv("DEEPSEEK_API_KEY")
    if not deepseek_api_key:
        print("DeepSeek API key not found")
        return
    
    # Markdown de teste simples
    markdown_content = """
# AAE Energy

AAE Energy is a renewable energy company based in Portugal.

## About Us
We specialize in solar and wind energy solutions for residential and commercial clients.

## Contact
- Website: https://aae.energy
- Industry: Renewable Energy
- Founded: 2015
- Location: Lisbon, Portugal
    """
    
    # Schema de teste
    schema = {
        "name": "string",
        "description": "string", 
        "industry": "string",
        "founded": "string",
        "headquarters": "string",
        "website": "string"
    }
    
    # Criar prompt para extração
    prompt = f"""Extraia informações estruturadas sobre a empresa a partir do seguinte conteúdo de website:
    
    {markdown_content}
    
    Retorne apenas um objeto JSON válido seguindo este schema:
    {json.dumps(schema, indent=2)}
    
    Não inclua explicações, apenas o JSON válido.
    """
    
    try:
        # Fazer requisição para DeepSeek
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.deepseek.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {deepseek_api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "deepseek-chat",
                    "messages": [
                        {
                            "role": "system",
                            "content": "Você é um assistente especializado em extrair informações estruturadas de textos. Retorne apenas JSON válido sem explicações adicionais."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    "temperature": 0
                },
                timeout=30.0
            )
        
        print(f"Status Code: {response.status_code}")
        
        if response.status_code != 200:
            print(f"DeepSeek API error: {response.status_code}")
            print(f"Response: {response.text}")
            return
        
        result = response.json()
        content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
        
        print(f"Raw DeepSeek Response:")
        print(content)
        print("\n" + "="*50 + "\n")
        
        # Tentar extrair o JSON da resposta
        import re
        json_match = re.search(r'```json\s*(.+?)\s*```', content, re.DOTALL)
        if json_match:
            json_str = json_match.group(1)
        else:
            json_str = content
        
        # Limpar e analisar o JSON
        json_str = re.sub(r'^```json\s*|\s*```$', '', json_str.strip())
        
        print(f"Extracted JSON String:")
        print(json_str)
        print("\n" + "="*50 + "\n")
        
        # Tentar diferentes abordagens para extrair JSON válido
        try:
            extracted_data = json.loads(json_str)
            print("Successfully parsed JSON:")
            print(json.dumps(extracted_data, indent=2))
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {e}")
            # Tentar encontrar qualquer objeto JSON na string
            json_pattern = re.search(r'\{.*\}', json_str, re.DOTALL)
            if json_pattern:
                try:
                    extracted_data = json.loads(json_pattern.group(0))
                    print("Successfully parsed JSON from pattern:")
                    print(json.dumps(extracted_data, indent=2))
                except Exception as e2:
                    print(f"Failed to parse JSON from pattern: {e2}")
                    print(f"Pattern content: {json_pattern.group(0)[:200]}")
            else:
                print("No JSON pattern found in response")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(test_deepseek_extraction())