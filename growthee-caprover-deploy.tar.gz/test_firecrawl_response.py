import os
from dotenv import load_dotenv
from firecrawl import FirecrawlApp

# Carregar variáveis de ambiente
load_dotenv()

def test_firecrawl_response():
    api_key = os.getenv('FIRECRAWL_API_KEY')
    if not api_key:
        print("FIRECRAWL_API_KEY não encontrada")
        return
    
    app = FirecrawlApp(api_key=api_key)
    url = "https://microsoft.com"
    
    print(f"Testando resposta do Firecrawl para: {url}")
    
    try:
        scraped_data = app.scrape_url(url)
        
        print(f"\nTipo da resposta: {type(scraped_data)}")
        print(f"Atributos da resposta: {dir(scraped_data)}")
        
        # Tentar diferentes formas de acessar o conteúdo
        if hasattr(scraped_data, 'markdown'):
            print(f"\nMarkdown via atributo: {len(scraped_data.markdown) if scraped_data.markdown else 'None'} caracteres")
            if scraped_data.markdown:
                print(f"Primeiros 200 caracteres: {scraped_data.markdown[:200]}...")
        
        if hasattr(scraped_data, 'data'):
            print(f"\nData via atributo: {type(scraped_data.data)}")
            if isinstance(scraped_data.data, dict):
                print(f"Keys em data: {list(scraped_data.data.keys())}")
                if 'markdown' in scraped_data.data:
                    markdown = scraped_data.data['markdown']
                    print(f"Markdown via data['markdown']: {len(markdown) if markdown else 'None'} caracteres")
        
        # Tentar converter para dict
        if hasattr(scraped_data, '__dict__'):
            print(f"\n__dict__: {list(scraped_data.__dict__.keys())}")
        
        # Tentar acessar como string
        print(f"\nString representation: {str(scraped_data)[:200]}...")
        
    except Exception as e:
        print(f"Erro: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_firecrawl_response()