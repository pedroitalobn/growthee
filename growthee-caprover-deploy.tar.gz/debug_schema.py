import sys
sys.path.append('/Users/pedrob/Documents/Dev/enrichStory')

from api.services import CompanyEnrichmentService
from api.log_service import LogService
import json
from unittest.mock import Mock

# Configurar serviços
log_service = LogService()
db_session = Mock()  # Mock da sessão do banco
enrichment_service = CompanyEnrichmentService(db_session, log_service)

# Testar o schema padrão
print("=== SCHEMA PADRÃO ===")
default_schema = enrichment_service._get_default_schema()
print(json.dumps(default_schema, indent=2))

# Simular dados extraídos (como retornados pelo DeepSeek)
print("\n=== DADOS EXTRAÍDOS SIMULADOS ===")
extracted_data = {
    "name": "Microsoft Corporation",
    "description": "Multinational technology corporation",
    "industry": "Technology",
    "founded": "1975",
    "headquarters": "Redmond, Washington, USA",
    "website": "https://microsoft.com",
    "size": "Large (100,000+ employees)"
}
print(json.dumps(extracted_data, indent=2))

# Testar mapeamento
print("\n=== RESULTADO DO MAPEAMENTO ===")
mapped_data = enrichment_service._map_data_to_schema(extracted_data, default_schema)
print(json.dumps(mapped_data, indent=2))

# Verificar campos preenchidos
print("\n=== ANÁLISE DOS CAMPOS ===")
filled_fields = []
for key, value in mapped_data.items():
    if key != '_metadata' and value is not None and value != "":
        filled_fields.append(key)
        print(f"✓ {key}: {value}")
    elif key != '_metadata':
        print(f"✗ {key}: {value}")

print(f"\nCampos preenchidos: {len(filled_fields)}")
print(f"Total de campos no schema: {len(default_schema.get('properties', default_schema))}")