#!/usr/bin/env python3
"""
Teste para verificar se a busca por redes sociais em páginas de contato está funcionando
"""

import asyncio
import os
import sys
from dotenv import load_dotenv

# Adicionar o diretório raiz ao path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Carregar variáveis de ambiente
load_dotenv()

async def test_contact_page_scraping():
    """Testa a busca por redes sociais em páginas de contato"""
    
    # Configurar banco de dados em memória para teste
    engine = create_engine("sqlite:///:memory:")
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db_session = SessionLocal()
    
    # Configurar serviços
    log_service = LogService()
    enrichment_service = CompanyEnrichmentService(db_session, log_service)
    
    try:
        print("🔍 Testando busca por redes sociais em páginas de contato...")
        
        # Teste 1: Site que pode ter redes sociais em páginas de contato
        test_urls = [
            "https://example.com",  # Site simples para teste
            "https://rvb.com.br",   # Site real que já testamos
        ]
        
        for url in test_urls:
            print(f"\n📄 Testando URL: {url}")
            
            # Testar a função de scraping de páginas de contato diretamente
            contact_social_media = await enrichment_service._scrape_contact_pages_for_social_media(url)
            
            print(f"Redes sociais encontradas em páginas de contato:")
            found_any = False
            for platform, social_url in contact_social_media.items():
                if social_url:
                    print(f"  - {platform}: {social_url}")
                    found_any = True
            
            if not found_any:
                print("  ❌ Nenhuma rede social encontrada em páginas de contato")
            else:
                print("  ✅ Redes sociais encontradas!")
            
            # Testar a função principal de scraping que inclui busca em contato
            print(f"\n🌐 Testando scraping completo do website...")
            website_result = await enrichment_service._scrape_company_website(url)
            
            if website_result.get('success'):
                data = website_result.get('data', {})
                social_media = data.get('social_media', {})
                
                print(f"Resultado do scraping completo:")
                print(f"  - Sucesso: {website_result.get('success')}")
                print(f"  - Fonte: {website_result.get('source')}")
                print(f"  - Confiança: {website_result.get('confidence_score')}")
                
                print(f"Redes sociais no resultado final:")
                found_any_final = False
                for platform, social_url in social_media.items():
                    if social_url:
                        print(f"  - {platform}: {social_url}")
                        found_any_final = True
                
                # Verificar também no nível raiz
                social_platforms = ['instagram', 'linkedin', 'facebook', 'youtube', 'whatsapp', 'twitter']
                for platform in social_platforms:
                    if data.get(platform) and not social_media.get(platform):
                        print(f"  - {platform} (raiz): {data.get(platform)}")
                        found_any_final = True
                
                if not found_any_final:
                    print("  ❌ Nenhuma rede social no resultado final")
                else:
                    print("  ✅ Redes sociais encontradas no resultado final!")
            else:
                print(f"  ❌ Falha no scraping: {website_result}")
            
            print("\n" + "="*60)
        
        # Teste 3: Verificar se a função de verificação de redes sociais funciona
        print("\n🔍 Testando função de verificação de redes sociais...")
        
        # Dados de teste com redes sociais
        test_data_with_social = {
            'social_media': {
                'instagram': 'https://instagram.com/test',
                'linkedin': 'https://linkedin.com/company/test'
            }
        }
        
        # Dados de teste sem redes sociais
        test_data_without_social = {
            'name': 'Test Company',
            'description': 'A test company'
        }
        
        has_social_1 = enrichment_service._check_social_media_found(test_data_with_social)
        has_social_2 = enrichment_service._check_social_media_found(test_data_without_social)
        
        print(f"Dados com redes sociais: {has_social_1} ✅" if has_social_1 else f"Dados com redes sociais: {has_social_1} ❌")
        print(f"Dados sem redes sociais: {not has_social_2} ✅" if not has_social_2 else f"Dados sem redes sociais: {not has_social_2} ❌")
        
        # Teste 4: Verificar função de merge
        print("\n🔄 Testando função de merge de redes sociais...")
        
        main_data = {
            'name': 'Test Company',
            'social_media': {
                'instagram': 'https://instagram.com/existing'
            }
        }
        
        contact_social = {
            'linkedin': 'https://linkedin.com/company/from-contact',
            'facebook': 'https://facebook.com/from-contact'
        }
        
        merged_data = enrichment_service._merge_contact_social_media(main_data, contact_social)
        
        print(f"Dados principais: {main_data}")
        print(f"Redes sociais do contato: {contact_social}")
        print(f"Dados após merge: {merged_data}")
        
        # Verificar se o merge funcionou corretamente
        expected_social = {
            'instagram': 'https://instagram.com/existing',  # Deve manter o existente
            'linkedin': 'https://linkedin.com/company/from-contact',  # Deve adicionar do contato
            'facebook': 'https://facebook.com/from-contact'  # Deve adicionar do contato
        }
        
        merge_success = all(
            merged_data.get('social_media', {}).get(platform) == expected_url
            for platform, expected_url in expected_social.items()
        )
        
        print(f"Merge funcionou corretamente: {merge_success} ✅" if merge_success else f"Merge funcionou corretamente: {merge_success} ❌")
        
    except Exception as e:
        print(f"❌ Erro durante o teste: {str(e)}")
        import traceback
        traceback.print_exc()
    
    finally:
        db_session.close()
        print("\n✅ Teste de busca em páginas de contato concluído!")

if __name__ == "__main__":
    asyncio.run(test_contact_page_scraping())