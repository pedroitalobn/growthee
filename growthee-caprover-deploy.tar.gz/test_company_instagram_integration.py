import asyncio
import json
import os
import sys

# Add the project root to the Python path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# Import the necessary modules
from api.log_service import LogService
from api.services.mock_instagram_scraper import MockInstagramScraperService

# Create a simplified version of CompanyEnrichmentService for testing
class TestCompanyEnrichmentService:
    def __init__(self, log_service):
        self.log_service = log_service
        self.instagram_scraper = MockInstagramScraperService(log_service)
    
    async def _enrich_by_instagram(self, instagram_url):
        """Enrich company data with Instagram profile information"""
        try:
            self.log_service.log_debug("Enriching company with Instagram data", {"url": instagram_url})
            
            # Call the Instagram scraper
            instagram_result = await self.instagram_scraper.scrape_profile(instagram_url)
            
            if "error" in instagram_result:
                return {"error": instagram_result["error"]}
            
            if "data" not in instagram_result:
                return {"error": "No data returned from Instagram scraper"}
            
            # Extract the data
            instagram_data = instagram_result["data"]
            
            # Map the data to the company enrichment format
            mapped_data = {
                "name": instagram_data.get("name"),
                "description": instagram_data.get("bio"),
                "website": instagram_data.get("website"),
                "instagram": {
                    "username": instagram_data.get("username"),
                    "followers_count": instagram_data.get("followers_count"),
                    "following_count": instagram_data.get("following_count"),
                    "posts_count": instagram_data.get("posts_count"),
                    "business_category": instagram_data.get("business_category"),
                    "location": instagram_data.get("location")
                }
            }
            
            return mapped_data
            
        except Exception as e:
            self.log_service.log_error("Error enriching company with Instagram data", {"error": str(e)})
            return {"error": f"Error enriching company with Instagram data: {str(e)}"}

async def test_company_instagram_integration():
    """Test the integration between CompanyEnrichmentService and MockInstagramScraperService"""
    print("\n===== Testing Company Enrichment with Instagram Integration =====")
    print("Testing different formats for Instagram profile input (username, URL)\n")
    
    # Initialize services
    log_service = LogService()
    company_service = TestCompanyEnrichmentService(log_service)
    
    # Test URLs and usernames with different formats
    test_inputs = [
        # Test the requested profile in different formats
        "festivaldocavalo",                           # Direct username
        "@festivaldocavalo",                          # Username with @ prefix
        "https://www.instagram.com/festivaldocavalo/", # Full URL
        "instagram.com/festivaldocavalo",             # URL without protocol
        
        # Original test cases
        "https://www.instagram.com/nike/",
        "apple",  # Direct username instead of URL
        "@microsoft",  # Username with @ prefix
    ]
    
    for input_value in test_inputs:
        print(f"\nTesting input: {input_value}")
        try:
            # Call the enrichment method
            result = await company_service._enrich_by_instagram(input_value)
            
            # Print the result
            print(f"Result for {input_value}:")
            print(json.dumps(result, indent=2))
            
            # Check if we got expected data
            if "error" in result:
                print(f"Error: {result['error']}")
            else:
                print(f"Success! Extracted data for {result.get('instagram', {}).get('username')}")
                print(f"Name: {result.get('name')}")
                print(f"Description: {result.get('description')[:50]}..." if result.get('description') and len(result.get('description')) > 50 else f"Description: {result.get('description')}")
                print(f"Website: {result.get('website')}")
                print(f"Followers: {result.get('instagram', {}).get('followers_count')}")
        
        except Exception as e:
            print(f"Exception: {str(e)}")

if __name__ == "__main__":
    asyncio.run(test_company_instagram_integration())