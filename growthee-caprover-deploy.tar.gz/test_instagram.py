import asyncio
import os
from dotenv import load_dotenv
from api.services.puppeteer_instagram_scraper import PuppeteerInstagramScraperService
from api.services.hyperbrowser_instagram_scraper import HyperbrowserInstagramScraperService
from api.log_service import LogService

# Carregar variáveis de ambiente
load_dotenv()

# Verificar se a chave API do Firecrawl está configurada
firecrawl_api_key = os.getenv("FIRECRAWL_API_KEY")
if not firecrawl_api_key:
    print("ERRO: FIRECRAWL_API_KEY não está configurada no arquivo .env")
    exit(1)

# Função para imprimir dados do perfil
def print_profile_data(profile_data, service_name):
    print(f"\n=== Resultados do {service_name} ===")
    if not profile_data:
        print(f"Falha ao extrair dados do perfil com {service_name}")
        return
    
    print(f"Username: {profile_data.get('username')}")
    print(f"Nome: {profile_data.get('name')}")
    print(f"Bio: {profile_data.get('bio')}")
    print(f"Seguidores: {profile_data.get('followers')} ({profile_data.get('followers_count')})")
    print(f"Seguindo: {profile_data.get('following')} ({profile_data.get('following_count')})")
    print(f"Posts: {profile_data.get('posts')} ({profile_data.get('posts_count')})")
    print(f"Website: {profile_data.get('website')}")
    print(f"Email: {profile_data.get('email')}")
    print(f"Categoria: {profile_data.get('business_category')}")
    print(f"\nDados brutos: {profile_data}")

# Função principal assíncrona
async def main():
    # Inicializar serviços
    log_service = LogService()
    hyperbrowser_scraper = HyperbrowserInstagramScraperService(log_service)
    puppeteer_scraper = PuppeteerInstagramScraperService(log_service)
    
    # URLs de teste
    instagram_urls = [
        "https://www.instagram.com/nike/",
        # "https://www.instagram.com/apple/",
        # "https://www.instagram.com/microsoft/"
    ]
    
    # Testar cada URL
    for url in instagram_urls:
        print(f"\n\n==== Testando URL: {url} ====\n")
        
        # Testar com Hyperbrowser
        try:
            hyperbrowser_result = await hyperbrowser_scraper.scrape_profile(url)
            print_profile_data(hyperbrowser_result, "Hyperbrowser")
        except Exception as e:
            print(f"Erro ao usar Hyperbrowser: {str(e)}")
        
        # Testar com Puppeteer
        try:
            puppeteer_result = await puppeteer_scraper.scrape_profile(url)
            print_profile_data(puppeteer_result, "Puppeteer")
        except Exception as e:
            print(f"Erro ao usar Puppeteer: {str(e)}")

# Executar o script
if __name__ == "__main__":
    asyncio.run(main())