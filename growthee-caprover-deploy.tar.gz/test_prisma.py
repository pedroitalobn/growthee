#!/usr/bin/env python3
import asyncio
from prisma import Prisma

async def test_prisma():
    prisma = Prisma()
    await prisma.connect()
    
    try:
        # Test basic connection
        print("Connected to database successfully")
        
        # Try to find a user by email
        user = await prisma.user.find_unique(
            where={"email": "admin@admin.com"}
        )
        
        if user:
            print(f"Found user: {user.email}")
            print(f"Full name: {user.fullName}")
        else:
            print("No user found")
            
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        await prisma.disconnect()

if __name__ == "__main__":
    asyncio.run(test_prisma())