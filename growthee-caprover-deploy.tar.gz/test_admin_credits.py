import requests
import json

# Configuração
BASE_URL = "http://localhost:8000"
LOGIN_URL = f"{BASE_URL}/api/v1/auth/login"
ADD_CREDITS_URL = f"{BASE_URL}/api/v1/credits/admin/add"
BALANCE_URL = f"{BASE_URL}/api/v1/credits/balance"

# Credenciais de login
login_data = {
    "emailOrUsername": "test@test.com",
    "password": "test123"
}

# Dados para adicionar créditos
credits_data = {
    "email": "test@test.com",
    "credits": 500,
    "description": "Créditos de teste adicionados via endpoint administrativo"
}

def test_admin_credits():
    # 1. Fazer login
    print("Fazendo login...")
    login_response = requests.post(LOGIN_URL, json=login_data)
    print(f"Status do login: {login_response.status_code}")
    
    if login_response.status_code != 200:
        print(f"Erro no login: {login_response.text}")
        return
    
    # Extrair token do response
    login_result = login_response.json()
    token = login_result.get("access_token")
    
    if not token:
        print("Token não encontrado na resposta do login")
        return
    
    print(f"Login realizado com sucesso. Token: {token[:20]}...")
    
    # Headers com JWT Bearer token
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # 2. Adicionar créditos
    print("\nAdicionando créditos...")
    add_response = requests.post(ADD_CREDITS_URL, json=credits_data, headers=headers)
    print(f"Status da adição de créditos: {add_response.status_code}")
    
    if add_response.status_code == 200:
        result = add_response.json()
        print(f"Créditos adicionados com sucesso: {json.dumps(result, indent=2)}")
    else:
        print(f"Erro ao adicionar créditos: {add_response.text}")
    
    # 3. Verificar saldo atual
    print("\nVerificando saldo atual...")
    balance_response = requests.get(BALANCE_URL, headers=headers)
    print(f"Status da consulta de saldo: {balance_response.status_code}")
    
    if balance_response.status_code == 200:
        balance = balance_response.json()
        print(f"Saldo atual: {json.dumps(balance, indent=2)}")
    else:
        print(f"Erro ao consultar saldo: {balance_response.text}")

if __name__ == "__main__":
    test_admin_credits()