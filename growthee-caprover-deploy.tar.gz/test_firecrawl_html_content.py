#!/usr/bin/env python3

import asyncio
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session
from unittest.mock import Mock
import re

async def test_firecrawl_html_content():
    """Testa o conteúdo HTML capturado pelo Firecrawl para verificar se contém as redes sociais"""
    
    # Mock da sessão do banco
    mock_session = Mock(spec=Session)
    log_service = LogService()
    
    # Criar instância do serviço
    enrichment_service = CompanyEnrichmentService(mock_session, log_service)
    
    # Schema de teste simples
    test_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "description": {"type": "string"}
        }
    }
    
    print("=== TESTE: Análise do Conteúdo HTML do Firecrawl ===")
    print(f"URL de teste: rvb.com.br")
    print()
    
    try:
        # Testar a função _scrape_with_firecrawl
        result = await enrichment_service._scrape_with_firecrawl(
            "https://rvb.com.br", 
            test_schema
        )
        
        if result and not result.get('error'):
            html_content = result.get('html')
            
            if html_content:
                print("=== ANÁLISE DO HTML CAPTURADO ===")
                print(f"Tamanho do HTML: {len(html_content)} caracteres")
                print()
                
                # Buscar por padrões de redes sociais no HTML
                social_patterns = {
                    'Instagram': [
                        r'instagram\.com/[\w\.-]+',
                        r'@[\w\.-]+.*instagram',
                        r'instagram.*@[\w\.-]+'
                    ],
                    'LinkedIn': [
                        r'linkedin\.com/company/[\w\.-]+',
                        r'linkedin\.com/in/[\w\.-]+',
                        r'br\.linkedin\.com/[\w\.-]+'
                    ],
                    'WhatsApp': [
                        r'wa\.me/[\d\+\-\s]+',
                        r'whatsapp.*[\d\+\-\s\(\)]{8,}',
                        r'api\.whatsapp\.com/send\?phone=[\d\+]+'
                    ],
                    'Facebook': [
                        r'facebook\.com/[\w\.-]+',
                        r'fb\.com/[\w\.-]+'
                    ],
                    'Twitter': [
                        r'twitter\.com/[\w\.-]+',
                        r'x\.com/[\w\.-]+'
                    ],
                    'YouTube': [
                        r'youtube\.com/[\w\.-]+',
                        r'youtu\.be/[\w\.-]+'
                    ]
                }
                
                found_social = {}
                
                for platform, patterns in social_patterns.items():
                    matches = []
                    for pattern in patterns:
                        found = re.findall(pattern, html_content, re.IGNORECASE)
                        matches.extend(found)
                    
                    if matches:
                        found_social[platform] = list(set(matches))  # Remove duplicatas
                        print(f"✅ {platform}: {found_social[platform]}")
                    else:
                        print(f"❌ {platform}: Não encontrado")
                
                print()
                
                # Buscar por números de telefone
                phone_patterns = [
                    r'\+55\s*\(?\d{2}\)?\s*\d{4,5}[\-\s]?\d{4}',
                    r'\(?\d{2}\)?\s*\d{4,5}[\-\s]?\d{4}',
                    r'\d{2}\s*\d{4,5}[\-\s]?\d{4}'
                ]
                
                print("=== BUSCA POR TELEFONES ===")
                phones_found = []
                for pattern in phone_patterns:
                    phones = re.findall(pattern, html_content)
                    phones_found.extend(phones)
                
                if phones_found:
                    unique_phones = list(set(phones_found))
                    print(f"📞 Telefones encontrados: {unique_phones}")
                else:
                    print("❌ Nenhum telefone encontrado")
                
                print()
                
                # Buscar por texto específico relacionado a redes sociais
                print("=== BUSCA POR TEXTO DE REDES SOCIAIS ===")
                social_keywords = ['instagram', 'linkedin', 'whatsapp', 'facebook', 'twitter', 'youtube']
                
                for keyword in social_keywords:
                    # Buscar o keyword e contexto ao redor
                    pattern = rf'.{{0,50}}{keyword}.{{0,50}}'
                    matches = re.findall(pattern, html_content, re.IGNORECASE)
                    
                    if matches:
                        print(f"🔍 Contexto '{keyword}': {matches[:3]}...")  # Mostrar apenas os primeiros 3
                    else:
                        print(f"❌ '{keyword}': Não encontrado no HTML")
                
                print()
                
                # Verificar se há JSON-LD no HTML
                print("=== BUSCA POR JSON-LD ===")
                json_ld_pattern = r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>([^<]+)</script>'
                json_ld_matches = re.findall(json_ld_pattern, html_content, re.IGNORECASE | re.DOTALL)
                
                if json_ld_matches:
                    print(f"📋 JSON-LD encontrado: {len(json_ld_matches)} blocos")
                    for i, json_content in enumerate(json_ld_matches[:2]):  # Mostrar apenas os primeiros 2
                        print(f"JSON-LD {i+1}: {json_content[:200]}...")
                else:
                    print("❌ Nenhum JSON-LD encontrado")
                    
            else:
                print("❌ HTML não foi capturado pelo Firecrawl")
                
        else:
            print(f"❌ Erro no Firecrawl: {result.get('error', 'Erro desconhecido')}")
            
    except Exception as e:
        print(f"❌ Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_firecrawl_html_content())