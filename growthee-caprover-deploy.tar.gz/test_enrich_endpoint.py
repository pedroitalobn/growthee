#!/usr/bin/env python3
import requests
import json

# Test the enrichment endpoints
base_url = "http://localhost:8000"

# Login first
login_response = requests.post(f"{base_url}/api/v1/auth/login", json={
    "emailOrUsername": "test@test.com",
    "password": "test123"
})

if login_response.status_code != 200:
    print(f"Login failed: {login_response.status_code} - {login_response.text}")
    exit(1)

token = login_response.json()["access_token"]
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

print(f"✅ Login successful, token: {token[:20]}...")

# Test company enrichment
print("\n🏢 Testing company enrichment...")
company_data = {"domain": "google.com"}
company_response = requests.post(f"{base_url}/api/v1/enrich/company", json=company_data, headers=headers)

print(f"Status: {company_response.status_code}")
if company_response.status_code == 200:
    result = company_response.json()
    print(f"✅ Company enrichment successful")
    print(f"Company name: {result.get('name', 'N/A')}")
    description = result.get('description', 'N/A')
    if description and description != 'N/A':
        print(f"Description: {description[:100]}...")
    else:
        print(f"Description: {description}")
    print(f"Full response: {json.dumps(result, indent=2)[:500]}...")
else:
    print(f"❌ Company enrichment failed: {company_response.text}")

# Test person enrichment
print("\n👤 Testing person enrichment...")
person_data = {"email": "test@google.com"}
person_response = requests.post(f"{base_url}/api/v1/enrich/person", json=person_data, headers=headers)

print(f"Status: {person_response.status_code}")
if person_response.status_code == 200:
    result = person_response.json()
    print(f"✅ Person enrichment successful")
    print(f"Person name: {result.get('name', 'N/A')}")
    print(f"Company: {result.get('company', 'N/A')}")
else:
    print(f"❌ Person enrichment failed: {person_response.text}")

print("\n✨ Test completed!")