import sqlite3
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get database URL
db_url = os.getenv('DATABASE_URL')
if db_url and db_url.startswith('file:'):
    db_path = db_url.replace('file:', '')
else:
    db_path = 'dev.db'

print(f"Connecting to database: {db_path}")

try:
    # Connect to SQLite database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Test query to get user
    cursor.execute("SELECT id, email, credits_remaining, credits_total FROM users WHERE email = ?", ('test@test.com',))
    user = cursor.fetchone()
    
    if user:
        user_id, email, credits_remaining, credits_total = user
        print(f"User found: {email}")
        print(f"Current credits: {credits_remaining}/{credits_total}")
        
        # Update credits directly
        new_credits = credits_remaining + 500
        new_total = credits_total + 500
        
        cursor.execute(
            "UPDATE users SET credits_remaining = ?, credits_total = ? WHERE id = ?",
            (new_credits, new_total, user_id)
        )
        conn.commit()
        
        print(f"Credits updated: {new_credits}/{new_total}")
        
        # Verify update
        cursor.execute("SELECT credits_remaining, credits_total FROM users WHERE id = ?", (user_id,))
        updated_user = cursor.fetchone()
        print(f"Verified credits: {updated_user[0]}/{updated_user[1]}")
        
    else:
        print("User not found")
        
except Exception as e:
    print(f"Error: {e}")
finally:
    if conn:
        conn.close()