#!/usr/bin/env python3
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from api.services import CompanyEnrichmentService
from api.log_service import LogService
from sqlalchemy.orm import Session
from unittest.mock import Mock

# Mock da sessão do banco
db_session = Mock(spec=Session)
log_service = LogService()
service = CompanyEnrichmentService(db_session, log_service)

async def test_contact_social_extraction():
    print("=== Testando extração de redes sociais em páginas de contato ===")
    
    # Testar busca em páginas de contato
    result = await service._scrape_contact_pages_for_social_media("https://rvb.com.br")
    
    print(f"\nResultado da busca em páginas de contato:")
    print(f"- Sucesso: {result.get('success', False)}")
    print(f"- Fonte: {result.get('source', 'none')}")
    
    social_media = result.get('social_media', {})
    if social_media:
        print("\n=== Redes Sociais Encontradas ===")
        for platform, url in social_media.items():
            if url:
                print(f"✅ {platform.capitalize()}: {url}")
    else:
        print("\n❌ Nenhuma rede social encontrada")
    
    # Verificar se há dados nas páginas raspadas
    scraped_pages = result.get('scraped_pages', [])
    print(f"\nPáginas raspadas com sucesso: {len(scraped_pages)}")
    for page in scraped_pages:
        print(f"- {page['url']}: {len(page.get('content', ''))} caracteres")

if __name__ == "__main__":
    import asyncio
    asyncio.run(test_contact_social_extraction())