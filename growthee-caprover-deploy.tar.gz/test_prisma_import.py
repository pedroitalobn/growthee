import asyncio
from prisma import Prisma
from dotenv import load_dotenv
import os

load_dotenv()

async def test_prisma():
    print("Testing Prisma import and connection...")
    
    try:
        # Initialize Prisma
        db = Prisma()
        print("Prisma initialized successfully")
        
        # Connect to database
        await db.connect()
        print("Connected to database successfully")
        
        # Test simple query without select
        print("Testing simple user query...")
        user = await db.user.find_unique(where={"email": "test@test.com"})
        
        if user:
            print(f"User found: {user.email}")
            print(f"Credits: {user.creditsRemaining}/{user.creditsTotal}")
        else:
            print("User not found")
            
        # Test update query
        print("Testing user update...")
        updated_user = await db.user.update(
            where={"email": "test@test.com"},
            data={"creditsRemaining": user.creditsRemaining + 500}
        )
        
        if updated_user:
            print(f"User updated: {updated_user.email}")
            print(f"New credits: {updated_user.creditsRemaining}/{updated_user.creditsTotal}")
            
        await db.disconnect()
        print("Disconnected successfully")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_prisma())