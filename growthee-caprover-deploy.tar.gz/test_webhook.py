import requests
import json
import stripe
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

# Configurar Stripe
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

def test_webhook_endpoint():
    """Testa se o endpoint de webhook está acessível"""
    webhook_url = "http://localhost:8000/api/v1/billing/webhook"
    
    # Teste simples de conectividade
    try:
        response = requests.post(webhook_url, json={"test": "data"})
        print(f"Webhook endpoint status: {response.status_code}")
        print(f"Response: {response.text}")
    except Exception as e:
        print(f"Error testing webhook: {e}")

def create_test_webhook_event():
    """Cria um evento de teste no Stripe"""
    try:
        # Criar um evento de teste
        event = stripe.Event.create(
            type='checkout.session.completed',
            data={
                'object': {
                    'id': 'cs_test_123',
                    'object': 'checkout.session',
                    'metadata': {
                        'user_id': 'cmfcirpuk0000i81g8sn1zqry',
                        'plan_id': 'cmfczm09a0001i61fl799r0ac'
                    },
                    'subscription': 'sub_test_123'
                }
            }
        )
        print(f"Test event created: {event.id}")
        return event
    except Exception as e:
        print(f"Error creating test event: {e}")
        return None

if __name__ == "__main__":
    print("Testing Stripe webhook integration...")
    print("\n1. Testing webhook endpoint connectivity:")
    test_webhook_endpoint()
    
    print("\n2. Creating test webhook event:")
    create_test_webhook_event()
    
    print("\n3. Webhook secret configured:", "Yes" if os.getenv("STRIPE_WEBHOOK_SECRET") else "No")