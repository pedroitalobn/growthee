#!/usr/bin/env python3
import requests
import json

def test_login():
    url = "http://localhost:8000/auth/login"
    payload = {
        "emailOrUsername": "admin@admin.com",
        "password": "@Story987"
    }
    
    try:
        response = requests.post(url, json=payload)
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"Login successful! Token: {data.get('access_token', 'N/A')[:20]}...")
        else:
            print(f"Login failed with status {response.status_code}")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_login()