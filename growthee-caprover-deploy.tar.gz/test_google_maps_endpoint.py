#!/usr/bin/env python3
import requests
import json

def test_google_maps_endpoint():
    """Testa o endpoint do Google Maps"""
    
    # URL do endpoint de teste
    url = "http://localhost:8000/api/v1/scrapp/google-maps/test"
    
    # Dados de teste - URL de uma empresa no Google Maps
    test_data = {
        "url": "https://www.google.com/maps/place/McDonald's/@40.7589,-73.9851,15z/data=!4m6!3m5!1s0x89c2588f046ee661:0xea734c0c665c0e8f!8m2!3d40.7589!4d-73.9851!16s%2Fg%2F1q67jt6jt",
        "use_hyperbrowser": True
    }
    
    try:
        print(f"Testando endpoint: {url}")
        print(f"Dados enviados: {json.dumps(test_data, indent=2)}")
        print("\n" + "="*50)
        
        # Fazer requisição POST
        response = requests.post(url, json=test_data, timeout=120)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2, ensure_ascii=False)}")
        
        if response.status_code == 200:
            print("\n✅ Teste bem-sucedido!")
        else:
            print(f"\n❌ Teste falhou com status {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Erro na requisição: {e}")
    except json.JSONDecodeError as e:
        print(f"❌ Erro ao decodificar JSON: {e}")
        print(f"Response text: {response.text}")
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")

def test_google_maps_search_endpoint():
    """Testa o endpoint de busca do Google Maps"""
    
    # URL do endpoint de teste
    url = "http://localhost:8000/api/v1/scrapp/google-maps/search/test"
    
    # Dados de teste - busca por nome de empresa
    test_data = {
        "business_name": "Starbucks",
        "location": "New York",
        "use_hyperbrowser": True
    }
    
    try:
        print(f"\nTestando endpoint de busca: {url}")
        print(f"Dados enviados: {json.dumps(test_data, indent=2)}")
        print("\n" + "="*50)
        
        # Fazer requisição POST
        response = requests.post(url, json=test_data, timeout=120)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2, ensure_ascii=False)}")
        
        if response.status_code == 200:
            print("\n✅ Teste de busca bem-sucedido!")
        else:
            print(f"\n❌ Teste de busca falhou com status {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Erro na requisição: {e}")
    except json.JSONDecodeError as e:
        print(f"❌ Erro ao decodificar JSON: {e}")
        print(f"Response text: {response.text}")
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")

if __name__ == "__main__":
    print("🧪 Testando endpoints do Google Maps...\n")
    
    # Testar scraping por URL
    test_google_maps_endpoint()
    
    # Testar busca por nome
    test_google_maps_search_endpoint()
    
    print("\n🏁 Testes concluídos!")