import stripe
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

# Configurar Stripe
stripe_secret = os.getenv("STRIPE_SECRET_KEY")
print(f"Stripe Secret Key: {stripe_secret[:20]}..." if stripe_secret else "No Stripe Secret Key found")

if stripe_secret:
    stripe.api_key = stripe_secret
    
    try:
        # Testar conexão básica
        print("Testing Stripe connection...")
        customers = stripe.Customer.list(limit=1)
        print(f"✅ Stripe connection successful! Found {len(customers.data)} customers")
        
        # Testar criação de customer
        print("Testing customer creation...")
        test_customer = stripe.Customer.create(
            email="test@example.com",
            name="Test User",
            metadata={"user_id": "test123"}
        )
        print(f"✅ Customer created successfully: {test_customer.id}")
        
        # Limpar customer de teste
        stripe.Customer.delete(test_customer.id)
        print("✅ Test customer deleted")
        
    except Exception as e:
        print(f"❌ Stripe error: {e}")
else:
    print("❌ No Stripe secret key configured")