#!/usr/bin/env python3

import os
import sys
import re
from dotenv import load_dotenv
from firecrawl import FirecrawlApp
from bs4 import BeautifulSoup

def test_firecrawl_content():
    """Testa se o Firecrawl está capturando o conteúdo correto das páginas"""
    
    # Carregar variáveis de ambiente
    load_dotenv()
    
    try:
        
        # Configurar Firecrawl
        firecrawl_api_key = os.getenv("FIRECRAWL_API_KEY")
        if not firecrawl_api_key:
            print("❌ FIRECRAWL_API_KEY não encontrada")
            return
            
        firecrawl_app = FirecrawlApp(api_key=firecrawl_api_key)
        
        # URLs de teste
        test_urls = [
            "https://rvb.com.br/contato",
            "https://rvb.com.br/contact",
            "https://rvb.com.br"
        ]
        
        for url in test_urls:
            print(f"\n🔍 Testando URL: {url}")
            
            try:
                # Fazer scraping com Firecrawl
                scraped_data = firecrawl_app.scrape_url(
                    url,
                    formats=['markdown', 'html']
                )
                
                print(f"✅ Scraping bem-sucedido para {url}")
                print(f"📊 Tipo de resposta: {type(scraped_data)}")
                
                # Verificar HTML diretamente do objeto
                html_content = getattr(scraped_data, 'html', '') or ''
                if html_content:
                    print(f"📄 HTML capturado: {len(html_content)} caracteres")
                    
                    # Buscar por redes sociais no HTML
                    social_patterns = {
                        'Instagram': r'instagram\.com/[a-zA-Z0-9_.]+',
                        'LinkedIn': r'linkedin\.com/(?:company|in)/[a-zA-Z0-9-]+',
                        'Facebook': r'facebook\.com/[a-zA-Z0-9.]+',
                        'WhatsApp': r'(?:wa\.me/|whatsapp\.com/send\?phone=)[0-9+]+',
                        'Twitter/X': r'(?:twitter\.com|x\.com)/[a-zA-Z0-9_]+'
                    }
                    
                    found_socials = []
                    for platform, pattern in social_patterns.items():
                        matches = re.findall(pattern, html_content, re.IGNORECASE)
                        if matches:
                            found_socials.append(f"{platform}: {matches[:3]}")  # Primeiros 3 matches
                    
                    if found_socials:
                        print("🎯 Redes sociais encontradas no HTML:")
                        for social in found_socials:
                            print(f"   - {social}")
                    else:
                        print("❌ Nenhuma rede social encontrada no HTML")
                        
                    # Mostrar amostra do HTML
                    print(f"\n📝 Amostra do HTML (primeiros 500 chars):")
                    print(html_content[:500])
                    
                    # Verificar se tem links sociais específicos
                    soup = BeautifulSoup(html_content, 'html.parser')
                    social_links = soup.find_all('a', href=True)
                    social_hrefs = []
                    for link in social_links:
                        href = link.get('href', '')
                        if any(social in href.lower() for social in ['instagram', 'linkedin', 'facebook', 'whatsapp', 'twitter', 'x.com']):
                            social_hrefs.append(href)
                    
                    if social_hrefs:
                        print(f"\n🔗 Links sociais encontrados ({len(social_hrefs)}):")
                        for href in social_hrefs[:5]:  # Primeiros 5
                            print(f"   - {href}")
                    else:
                        print("\n❌ Nenhum link social encontrado nos elementos <a>")
                else:
                    print("❌ Nenhum conteúdo HTML capturado")
                
                # Verificar Markdown
                markdown_content = getattr(scraped_data, 'markdown', '') or ''
                if markdown_content:
                    print(f"\n📝 Markdown capturado: {len(markdown_content)} caracteres")
                    print(f"📝 Amostra do Markdown (primeiros 300 chars):")
                    print(markdown_content[:300])
                else:
                    print("\n❌ Nenhum conteúdo Markdown capturado")
                    
            except Exception as e:
                print(f"❌ Erro ao fazer scraping de {url}: {str(e)}")
                print(f"🔍 Tipo do erro: {type(e)}")
                
        print("\n" + "="*50)
        print("🧪 Teste de extração de redes sociais simples")
        print("="*50)
        
        # Testar extração simples com regex
        test_html = '''
        <html>
        <body>
            <a href="https://instagram.com/rvb_oficial">Instagram</a>
            <a href="https://linkedin.com/company/rvb-advogados">LinkedIn</a>
            <a href="https://facebook.com/rvbadvogados">Facebook</a>
            <a href="https://wa.me/5511999999999">WhatsApp</a>
        </body>
        </html>
        '''
        
        print("\n🧪 Testando extração com HTML de exemplo...")
        social_patterns = {
            'Instagram': r'instagram\.com/[a-zA-Z0-9_.]+',
            'LinkedIn': r'linkedin\.com/(?:company|in)/[a-zA-Z0-9-]+',
            'Facebook': r'facebook\.com/[a-zA-Z0-9.]+',
            'WhatsApp': r'(?:wa\.me/|whatsapp\.com/send\?phone=)[0-9+]+'
        }
        
        found_socials = []
        for platform, pattern in social_patterns.items():
            matches = re.findall(pattern, test_html, re.IGNORECASE)
            if matches:
                found_socials.append(f"{platform}: {matches}")
        
        print(f"📊 Resultado da extração: {found_socials}")
        
    except Exception as e:
        print(f"❌ Erro geral: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_firecrawl_content()