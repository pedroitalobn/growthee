import asyncio
import requests
import json
from prisma import Prisma
from datetime import datetime, timedelta

async def test_complete_payment_flow():
    """Testa o fluxo completo de pagamento simulando um webhook"""
    db = Prisma()
    await db.connect()
    
    try:
        # 1. Verificar usuário de teste
        user = await db.user.find_unique(
            where={"email": "client@client.com"}
        )
        
        if not user:
            print("❌ User not found")
            return
            
        print(f"✅ User found: {user.email} (ID: {user.id})")
        print(f"   Current plan: {user.plan}")
        print(f"   Credits remaining: {user.creditsRemaining}")
        
        # 2. Verificar plano Starter
        plan = await db.plan.find_unique(
            where={"id": "cmfczm09a0001i61fl799r0ac"}
        )
        
        if not plan:
            print("❌ Plan not found")
            return
            
        print(f"✅ Plan found: {plan.name} - ${plan.priceMonthly}/month")
        print(f"   Credits included: {plan.creditsIncluded}")
        print(f"   Stripe Price ID: {plan.stripePriceId}")
        
        # 3. Simular checkout session completed
        print("\n🔄 Simulating checkout session completed...")
        
        # Criar subscription simulada
        fake_subscription_id = "sub_test_simulation_123"
        current_time = datetime.now()
        
        # Verificar se já existe subscription ativa
        existing_sub = await db.subscription.find_first(
            where={
                "userId": user.id,
                "status": "ACTIVE"
            }
        )
        
        if existing_sub:
            print(f"⚠️  User already has active subscription: {existing_sub.id}")
            print("   Canceling existing subscription...")
            await db.subscription.update(
                where={"id": existing_sub.id},
                data={"status": "CANCELED"}
            )
        
        # Criar nova subscription
        subscription = await db.subscription.create(
            data={
                "userId": user.id,
                "planId": plan.id,
                "stripeSubscriptionId": fake_subscription_id,
                "status": "ACTIVE",
                "currentPeriodStart": current_time,
                "currentPeriodEnd": current_time + timedelta(days=30)
            }
        )
        
        print(f"✅ Subscription created: {subscription.id}")
        
        # 4. Atualizar usuário com novo plano
        updated_user = await db.user.update(
            where={"id": user.id},
            data={
                "plan": plan.type,
                "creditsRemaining": plan.creditsIncluded,
                "creditsTotal": plan.creditsIncluded
            }
        )
        
        print(f"✅ User updated:")
        print(f"   Plan: {updated_user.plan}")
        print(f"   Credits remaining: {updated_user.creditsRemaining}")
        print(f"   Credits total: {updated_user.creditsTotal}")
        
        # 5. Verificar subscription criada
        final_subscription = await db.subscription.find_unique(
            where={"id": subscription.id},
            include={"plan": True, "user": True}
        )
        
        print(f"\n✅ Final verification:")
        print(f"   Subscription ID: {final_subscription.id}")
        print(f"   Status: {final_subscription.status}")
        print(f"   Plan: {final_subscription.plan.name}")
        print(f"   User: {final_subscription.user.email}")
        print(f"   Period: {final_subscription.currentPeriodStart} to {final_subscription.currentPeriodEnd}")
        
        print("\n🎉 Payment flow simulation completed successfully!")
        
    except Exception as e:
        print(f"❌ Error during payment flow test: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await db.disconnect()

if __name__ == "__main__":
    print("Testing complete payment flow...")
    asyncio.run(test_complete_payment_flow())