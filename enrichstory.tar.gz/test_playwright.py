import asyncio
from playwright.async_api import async_playwright

async def test_playwright():
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto("https://www.google.com")
            title = await page.title()
            print(f"✅ Playwright funcionando! Título da página: {title}")
            await browser.close()
            return True
    except Exception as e:
        print(f"❌ Erro no Playwright: {str(e)}")
        return False

if __name__ == "__main__":
    asyncio.run(test_playwright())